import config from '../config/config.js';
import logger from '../utils/logger.js';

class OAuth2Service {
  generateAuthUrl(state, guildId) {
    const params = new URLSearchParams({
      client_id: config.bot.clientId,
      redirect_uri: config.bot.redirectUri,
      response_type: 'code',
      scope: 'guilds.join identify email',
      state: state || `${guildId}-${Date.now()}`
    });

    return `https://discord.com/api/oauth2/authorize?${params.toString()}`;
  }

  async exchangeCodeForToken(code) {
    try {
      const response = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          client_id: config.bot.clientId,
          client_secret: config.bot.clientSecret,
          grant_type: 'authorization_code',
          code: code,
          redirect_uri: config.bot.redirectUri
        })
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Token exchange failed: ${error}`);
      }

      const data = await response.json();
      return {
        access_token: data.access_token,
        refresh_token: data.refresh_token,
        expires_in: data.expires_in,
        scope: data.scope
      };
    } catch (error) {
      logger.error('OAuth2 token exchange error:', error);
      throw error;
    }
  }

  async refreshToken(refreshToken) {
    try {
      const response = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          client_id: config.bot.clientId,
          client_secret: config.bot.clientSecret,
          grant_type: 'refresh_token',
          refresh_token: refreshToken
        })
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Token refresh failed: ${error}`);
      }

      const data = await response.json();
      return {
        access_token: data.access_token,
        refresh_token: data.refresh_token,
        expires_in: data.expires_in
      };
    } catch (error) {
      logger.error('OAuth2 token refresh error:', error);
      throw error;
    }
  }

  async getUserGuilds(accessToken) {
    try {
      const response = await fetch('https://discord.com/api/users/@me/guilds', {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get user guilds: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      logger.error('Get user guilds error:', error);
      throw error;
    }
  }

  async joinGuild(guildId, userId, accessToken) {
    try {
      const response = await fetch(`https://discord.com/api/guilds/${guildId}/members/${userId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bot ${config.bot.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          access_token: accessToken
        })
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Failed to join guild: ${error}`);
      }

      // 204 = user already in guild, 201 = user added successfully
      // Both cases don't return JSON body
      if (response.status === 204 || response.status === 201) {
        return { success: true, alreadyMember: response.status === 204 };
      }

      // 200 = returns member object
      return await response.json();
    } catch (error) {
      logger.error('Join guild error:', error);
      throw error;
    }
  }
}

export default new OAuth2Service();
