import zlib from "zlib";
import { promisify } from "util";
import Backup from "../database/models/Backup.js";
import logger from "../utils/logger.js";

const gzip = promisify(zlib.gzip);
const gunzip = promisify(zlib.gunzip);

class BackupService {
  async createBackup(
    guildId,
    name,
    components,
    guild,
    createdBy,
    isAutoBackup = false
  ) {
    try {
      const backupData = {
        guild: {
          id: guild.id,
          name: guild.name,
          icon: guild.iconURL(),
          description: guild.description,
          region: guild.preferredLocale,
          verificationLevel: guild.verificationLevel,
          defaultMessageNotifications: guild.defaultMessageNotifications,
          explicitContentFilter: guild.explicitContentFilter,
          features: guild.features,
        },
        components: {},
      };

      // Backup server settings
      if (components.serverSettings) {
        backupData.components.serverSettings = backupData.guild;
      }

      // Backup roles (excluir cargos de bots e @everyone)
      if (components.roles) {
        backupData.components.roles = guild.roles.cache
          .filter((role) => {
            // Excluir @everyone
            if (role.id === guild.id) return false;
            // Excluir cargos gerenciados por bots
            if (role.managed) return false;
            return true;
          })
          .map((role) => ({
            id: role.id,
            name: role.name,
            color: role.color,
            hoist: role.hoist,
            mentionable: role.mentionable,
            permissions: role.permissions.toArray(),
            position: role.position,
          }));
      }

      // Backup channels
      if (components.channels) {
        backupData.components.channels = guild.channels.cache.map(
          (channel) => ({
            id: channel.id,
            name: channel.name,
            type: channel.type,
            position: channel.position,
            parentId: channel.parentId,
            topic: channel.topic,
            nsfw: channel.nsfw,
            bitrate: channel.bitrate,
            userLimit: channel.userLimit,
            permissionOverwrites: channel.permissionOverwrites.cache.map(
              (overwrite) => ({
                id: overwrite.id,
                type: overwrite.type,
                allow: overwrite.allow.toArray(),
                deny: overwrite.deny.toArray(),
              })
            ),
          })
        );
      }

      // Backup members
      if (components.members) {
        // Usar membros em cache para evitar rate limit
        // Se o cache estiver vazio, tentar fetch com tratamento de erro
        if (guild.members.cache.size <= 1) {
          try {
            await guild.members.fetch({ time: 30000 });
          } catch (fetchError) {
            logger.warn(
              `Failed to fetch members, using cache: ${fetchError.message}`
            );
          }
        }

        // Filtrar bots e mapear apenas membros humanos
        backupData.components.members = guild.members.cache
          .filter((member) => !member.user.bot)
          .map((member) => ({
            id: member.id,
            username: member.user.username,
            discriminator: member.user.discriminator,
            nickname: member.nickname,
            // Filtrar cargos de bots dos membros também
            roles: member.roles.cache
              .filter((role) => {
                // Excluir @everyone
                if (role.id === guild.id) return false;
                // Excluir cargos gerenciados por bots
                if (role.managed) return false;
                return true;
              })
              .map((role) => role.id),
            joinedAt: member.joinedAt,
            premiumSince: member.premiumSince,
          }));
      }

      // Backup messages (limited to recent messages per channel)
      if (components.messages) {
        backupData.components.messages = {};
        const textChannels = guild.channels.cache.filter((ch) =>
          ch.isTextBased()
        );

        for (const channel of textChannels.values()) {
          try {
            const messages = await channel.messages.fetch({ limit: 100 });
            // Filtrar mensagens de bots
            backupData.components.messages[channel.id] = messages
              .filter((msg) => !msg.author.bot)
              .map((msg) => ({
                id: msg.id,
                content: msg.content,
                authorId: msg.author.id,
                createdAt: msg.createdAt,
                attachments: msg.attachments.map((att) => ({
                  url: att.url,
                  name: att.name,
                })),
              }));
          } catch (error) {
            logger.warn(
              `Failed to backup messages from channel ${channel.id}:`,
              error.message
            );
          }
        }
      }

      // Backup emojis
      if (components.emojis) {
        backupData.components.emojis = guild.emojis.cache.map((emoji) => ({
          id: emoji.id,
          name: emoji.name,
          animated: emoji.animated,
          url: emoji.imageURL(),
        }));
      }

      // Backup stickers
      if (components.stickers) {
        backupData.components.stickers = guild.stickers.cache.map(
          (sticker) => ({
            id: sticker.id,
            name: sticker.name,
            description: sticker.description,
            format: sticker.format,
            url: sticker.url,
          })
        );
      }

      // Backup permissions
      if (components.permissions) {
        backupData.components.permissions = {
          roles:
            backupData.components.roles?.map((role) => ({
              id: role.id,
              permissions: role.permissions,
            })) || [],
          channels:
            backupData.components.channels?.map((channel) => ({
              id: channel.id,
              permissionOverwrites: channel.permissionOverwrites,
            })) || [],
        };
      }

      // Compress data
      const jsonData = JSON.stringify(backupData);
      const compressed = await gzip(jsonData);

      // Calculate metadata (contar apenas humanos e cargos não-bot)
      const humanMembers = components.members
        ? guild.members.cache.filter((m) => !m.user.bot).size
        : 0;
      const nonBotRoles = components.roles
        ? guild.roles.cache.filter((r) => r.id !== guild.id && !r.managed).size
        : 0;

      const metadata = {
        memberCount: humanMembers,
        channelCount: components.channels ? guild.channels.cache.size : 0,
        roleCount: nonBotRoles,
        messageCount: components.messages
          ? Object.values(backupData.components.messages || {}).reduce(
              (sum, msgs) => sum + msgs.length,
              0
            )
          : 0,
      };

      // Save backup
      const backup = new Backup({
        guildId,
        name,
        createdBy,
        size: compressed.length,
        compressed: true,
        includedComponents: components,
        data: compressed,
        metadata,
        isAutoBackup,
      });

      await backup.save();
      logger.info(`Backup created: ${name} (${backup._id})`);

      return backup;
    } catch (error) {
      logger.error("Backup creation error:", error);
      throw error;
    }
  }

  async getBackup(backupId) {
    try {
      const backup = await Backup.findById(backupId);
      if (!backup) {
        throw new Error("Backup not found");
      }
      return backup;
    } catch (error) {
      logger.error("Get backup error:", error);
      throw error;
    }
  }

  async listBackups(guildId, limit = 10, skip = 0) {
    try {
      const backups = await Backup.find({ guildId })
        .sort({ createdAt: -1 })
        .limit(limit)
        .skip(skip)
        .select("-data"); // Exclude data buffer for performance

      const total = await Backup.countDocuments({ guildId });

      return {
        backups,
        total,
        limit,
        skip,
      };
    } catch (error) {
      logger.error("List backups error:", error);
      throw error;
    }
  }

  async deleteBackup(backupId) {
    try {
      const backup = await Backup.findByIdAndDelete(backupId);
      if (!backup) {
        throw new Error("Backup not found");
      }
      logger.info(`Backup deleted: ${backupId}`);
      return backup;
    } catch (error) {
      logger.error("Delete backup error:", error);
      throw error;
    }
  }

  async decompressData(buffer) {
    try {
      const decompressed = await gunzip(buffer);
      return JSON.parse(decompressed.toString("utf8"));
    } catch (error) {
      logger.error("Decompress data error:", error);
      throw error;
    }
  }
}

export default new BackupService();
