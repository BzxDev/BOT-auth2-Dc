import cron from 'node-cron';
import AutoBackup from '../database/models/AutoBackup.js';
import BackupService from './BackupService.js';
import AuditLog from '../database/models/AuditLog.js';
import logger from '../utils/logger.js';

const intervalMap = {
  '1week': { hours: 168, cron: '0 0 * * 0' }, // Every Sunday at midnight
  '2weeks': { hours: 336, cron: null }, // Custom calculation needed
  '3weeks': { hours: 504, cron: null }, // Custom calculation needed
  '1month': { hours: 720, cron: '0 0 1 * *' } // First day of month at midnight
};

const scheduledJobs = new Map();

class SchedulerService {
  calculateNextBackup(interval) {
    const config = intervalMap[interval];
    if (!config) {
      throw new Error(`Invalid interval: ${interval}`);
    }

    const now = new Date();
    const nextBackup = new Date(now.getTime() + config.hours * 60 * 60 * 1000);
    return nextBackup;
  }

  getCronExpression(interval, nextBackup) {
    const config = intervalMap[interval];
    if (config.cron) {
      return config.cron;
    }

    // For custom intervals (2weeks, 3weeks), calculate cron based on nextBackup
    const date = new Date(nextBackup);
    const day = date.getDate();
    const hour = date.getHours();
    const minute = date.getMinutes();

    // Run at the same time on the calculated day
    return `${minute} ${hour} ${day} * *`;
  }

  async scheduleAutoBackup(guildId, interval, components, createdBy, client) {
    try {
      const intervalHours = intervalMap[interval].hours;
      const nextBackup = this.calculateNextBackup(interval);

      // Cancel existing schedule if any
      await this.cancelAutoBackup(guildId);

      // Create or update AutoBackup document
      const autoBackup = await AutoBackup.findOneAndUpdate(
        { guildId },
        {
          guildId,
          enabled: true,
          interval,
          intervalHours,
          includedComponents: components,
          nextBackup,
          createdBy,
          createdAt: new Date()
        },
        { upsert: true, new: true }
      );

      // Schedule cron job
      const cronExpression = this.getCronExpression(interval, nextBackup);
      const job = cron.schedule(cronExpression, async () => {
        await this.executeScheduledBackup(guildId, client);
      });

      scheduledJobs.set(guildId, {
        job,
        autoBackup
      });

      logger.info(`Auto-backup scheduled for guild ${guildId} with interval ${interval}`);

      return autoBackup;
    } catch (error) {
      logger.error('Schedule auto-backup error:', error);
      throw error;
    }
  }

  async cancelAutoBackup(guildId) {
    try {
      const scheduled = scheduledJobs.get(guildId);
      if (scheduled) {
        scheduled.job.stop();
        scheduledJobs.delete(guildId);
      }

      await AutoBackup.findOneAndUpdate(
        { guildId },
        { enabled: false }
      );

      logger.info(`Auto-backup cancelled for guild ${guildId}`);
    } catch (error) {
      logger.error('Cancel auto-backup error:', error);
      throw error;
    }
  }

  async getAutoBackup(guildId) {
    try {
      return await AutoBackup.findOne({ guildId });
    } catch (error) {
      logger.error('Get auto-backup error:', error);
      throw error;
    }
  }

  async executeScheduledBackup(guildId, client) {
    try {
      const autoBackup = await AutoBackup.findOne({ guildId, enabled: true });
      if (!autoBackup) {
        logger.warn(`No active auto-backup found for guild ${guildId}`);
        return;
      }

      const guild = await client.guilds.fetch(guildId);
      if (!guild) {
        logger.warn(`Guild ${guildId} not found`);
        return;
      }

      // Generate backup name
      const date = new Date();
      const backupName = `auto-backup-${date.toISOString().split('T')[0]}`;

      // Create backup
      const backup = await BackupService.createBackup(
        guildId,
        backupName,
        autoBackup.includedComponents,
        guild,
        'system',
        true
      );

      // Update auto-backup next execution time
      const nextBackup = this.calculateNextBackup(autoBackup.interval);
      autoBackup.lastBackup = new Date();
      autoBackup.nextBackup = nextBackup;
      await autoBackup.save();

      // Reschedule job with new nextBackup time
      const scheduled = scheduledJobs.get(guildId);
      if (scheduled) {
        scheduled.job.stop();
        const cronExpression = this.getCronExpression(autoBackup.interval, nextBackup);
        const newJob = cron.schedule(cronExpression, async () => {
          await this.executeScheduledBackup(guildId, client);
        });
        scheduledJobs.set(guildId, {
          job: newJob,
          autoBackup
        });
      }

      // Log to audit
      await AuditLog.create({
        action: 'auto_backup_created',
        userId: 'system',
        guildId,
        details: {
          backupId: backup._id,
          backupName,
          interval: autoBackup.interval
        }
      });

      logger.info(`Scheduled backup executed for guild ${guildId}: ${backupName}`);
    } catch (error) {
      logger.error('Execute scheduled backup error:', error);
    }
  }

  async loadAllSchedules(client) {
    try {
      const activeSchedules = await AutoBackup.find({ enabled: true });
      
      for (const schedule of activeSchedules) {
        // Check if nextBackup is in the past, recalculate if needed
        let nextBackup = schedule.nextBackup;
        if (nextBackup < new Date()) {
          nextBackup = this.calculateNextBackup(schedule.interval);
          schedule.nextBackup = nextBackup;
          await schedule.save();
        }

        const cronExpression = this.getCronExpression(schedule.interval, nextBackup);
        const job = cron.schedule(cronExpression, async () => {
          await this.executeScheduledBackup(schedule.guildId, client);
        });

        scheduledJobs.set(schedule.guildId, {
          job,
          autoBackup: schedule
        });

        logger.info(`Loaded auto-backup schedule for guild ${schedule.guildId}`);
      }

      logger.info(`Loaded ${activeSchedules.length} auto-backup schedules`);
    } catch (error) {
      logger.error('Load schedules error:', error);
      throw error;
    }
  }
}

export default new SchedulerService();
