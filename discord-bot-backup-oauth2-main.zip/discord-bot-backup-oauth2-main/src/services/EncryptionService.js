import crypto from "crypto";
import config from "../config/config.js";

const algorithm = "aes-256-cbc";

// Derive a 32-byte key using SHA-256
// Uses ENCRYPTION_KEY if provided, otherwise uses CLIENT_SECRET
const deriveKey = () => {
  const rawKey = config.encryption?.key || config.bot.clientSecret;
  return crypto.createHash("sha256").update(rawKey).digest();
};

const key = deriveKey();

class EncryptionService {
  encrypt(text) {
    try {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(algorithm, key, iv);

      let encrypted = cipher.update(text, "utf8", "hex");
      encrypted += cipher.final("hex");

      return iv.toString("hex") + ":" + encrypted;
    } catch (error) {
      throw new Error(`Encryption failed: ${error.message}`);
    }
  }

  decrypt(encryptedData) {
    try {
      const parts = encryptedData.split(":");
      if (parts.length !== 2) {
        throw new Error("Invalid encrypted data format");
      }

      const iv = Buffer.from(parts[0], "hex");
      const encrypted = parts[1];

      const decipher = crypto.createDecipheriv(algorithm, key, iv);

      let decrypted = decipher.update(encrypted, "hex", "utf8");
      decrypted += decipher.final("utf8");

      return decrypted;
    } catch (error) {
      throw new Error(`Decryption failed: ${error.message}`);
    }
  }
}

export default new EncryptionService();
