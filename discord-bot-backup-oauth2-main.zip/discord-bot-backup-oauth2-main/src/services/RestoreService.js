import BackupService from "./BackupService.js";
import OAuth2Service from "./OAuth2Service.js";
import OAuthToken from "../database/models/OAuthToken.js";
import GuildConfig from "../database/models/GuildConfig.js";
import EncryptionService from "./EncryptionService.js";
import logger from "../utils/logger.js";
import { PermissionFlagsBits, ChannelType } from "discord.js";

const restoreStatuses = new Map();

class RestoreService {
  async startRestore(backupId, targetGuildId, client) {
    try {
      const backup = await BackupService.getBackup(backupId);
      const backupData = await BackupService.decompressData(backup.data);

      const restoreId = `${backupId}-${Date.now()}`;
      restoreStatuses.set(restoreId, {
        status: "in_progress",
        progress: 0,
        steps: [],
        error: null,
      });

      // Start restore process asynchronously
      this.executeRestore(
        restoreId,
        backup,
        backupData,
        targetGuildId,
        client
      ).catch((error) => {
        logger.error("Restore execution error:", error);
        const status = restoreStatuses.get(restoreId);
        if (status) {
          status.status = "failed";
          status.error = error.message;
        }
      });

      return restoreId;
    } catch (error) {
      logger.error("Start restore error:", error);
      throw error;
    }
  }

  async executeRestore(restoreId, backup, backupData, targetGuildId, client) {
    const status = restoreStatuses.get(restoreId);
    if (!status) return;

    try {
      const targetGuild = await client.guilds.fetch(targetGuildId);
      if (!targetGuild) {
        throw new Error("Target guild not found");
      }

      // Restore server settings
      if (
        backup.includedComponents.serverSettings &&
        backupData.components.serverSettings
      ) {
        status.steps.push("Restaurando configurações do servidor...");
        status.progress = 10;
        await this.restoreServerSettings(
          targetGuild,
          backupData.components.serverSettings
        );
      }

      // Restore roles
      if (backup.includedComponents.roles && backupData.components.roles) {
        status.steps.push("Restaurando cargos...");
        status.progress = 30;
        await this.restoreRoles(targetGuild, backupData.components.roles);
      }

      // Restore channels
      if (
        backup.includedComponents.channels &&
        backupData.components.channels
      ) {
        status.steps.push("Restaurando canais...");
        status.progress = 50;
        await this.restoreChannels(targetGuild, backupData.components.channels);
      }

      // Restore emojis
      if (backup.includedComponents.emojis && backupData.components.emojis) {
        status.steps.push("Restaurando emojis...");
        status.progress = 70;
        await this.restoreEmojis(targetGuild, backupData.components.emojis);
      }

      // Restore stickers
      if (
        backup.includedComponents.stickers &&
        backupData.components.stickers
      ) {
        status.steps.push("Restaurando stickers...");
        status.progress = 80;
        await this.restoreStickers(targetGuild, backupData.components.stickers);
      }

      // Restore members (using OAuth2 tokens)
      if (backup.includedComponents.members && backupData.components.members) {
        status.steps.push("Restaurando membros...");
        status.progress = 90;
        await this.restoreMembers(targetGuild, backupData.components.members);
      }

      status.status = "completed";
      status.progress = 100;
      status.steps.push("Restauração concluída!");
    } catch (error) {
      status.status = "failed";
      status.error = error.message;
      throw error;
    }
  }

  async restoreServerSettings(guild, settings) {
    try {
      if (settings.name && guild.name !== settings.name) {
        await guild.setName(settings.name);
      }
      if (settings.description && guild.description !== settings.description) {
        await guild.setDescription(settings.description);
      }
      // Note: Some settings like verification level require specific permissions
    } catch (error) {
      logger.warn("Failed to restore some server settings:", error.message);
    }
  }

  async restoreRoles(guild, roles) {
    try {
      await guild.roles.fetch();

      const botMember = await guild.members.fetch(guild.client.user.id);
      const botHighestRole = botMember.roles.highest;
      const botPosition = botHighestRole ? botHighestRole.position : -1;

      // Verificar se o bot tem permissão ManageRoles
      const botHasManageRoles = botMember.permissions.has(
        PermissionFlagsBits.ManageRoles
      );

      if (!botHasManageRoles) {
        logger.warn(
          `Bot does not have ManageRoles permission. Some roles may not be restored. ` +
            `Bot's highest role position: ${botPosition}`
        );
      }

      // Sort by position
      const sortedRoles = roles.sort((a, b) => b.position - a.position);

      for (const roleData of sortedRoles) {
        try {
          if (roleData.id === guild.id) continue;

          if (roleData.position >= botPosition) {
            logger.warn(
              `Skipping role ${roleData.name}: position (${roleData.position}) >= bot position (${botPosition})`
            );
            continue;
          }

          if (!botHasManageRoles) {
            logger.warn(
              `Skipping role ${roleData.name}: bot lacks ManageRoles permission`
            );
            continue;
          }

          let role = guild.roles.cache.find((r) => r.name === roleData.name);

          if (!role) {
            role = await guild.roles.create({
              name: roleData.name,
              color: roleData.color,
              hoist: roleData.hoist,
              mentionable: roleData.mentionable,
              permissions: roleData.permissions,
              reason: "Restore from backup",
            });
            logger.info(`Created role: ${roleData.name}`);
          } else {
            if (role.position >= botPosition) {
              logger.warn(
                `Skipping edit of existing role ${roleData.name}: position (${role.position}) >= bot position (${botPosition})`
              );
              continue;
            }

            await role.edit({
              name: roleData.name,
              color: roleData.color,
              hoist: roleData.hoist,
              mentionable: roleData.mentionable,
              permissions: roleData.permissions,
            });
            logger.info(`Updated existing role: ${roleData.name}`);
          }
        } catch (error) {
          logger.warn(
            `Failed to restore role ${roleData.name}:`,
            error.message
          );
        }
      }
    } catch (error) {
      logger.error("Restore roles error:", error);
      throw error;
    }
  }

  async restoreChannels(guild, channels) {
    try {
      await guild.channels.fetch();

      const config = await GuildConfig.findOne({ guildId: guild.id });
      const restoreMode = config?.channelRestoreMode || "automatic";

      const categories = channels.filter(
        (c) => c.type === ChannelType.GuildCategory
      );
      const regularChannels = channels.filter(
        (c) => c.type !== ChannelType.GuildCategory
      );

      const sortedCategories = categories.sort(
        (a, b) => a.position - b.position
      );
      const sortedChannels = regularChannels.sort(
        (a, b) => a.position - b.position
      );

      const categoryMap = new Map();

      for (const categoryData of sortedCategories) {
        try {
          const existingCategory = guild.channels.cache.find(
            (c) =>
              c.name === categoryData.name &&
              c.type === ChannelType.GuildCategory
          );

          if (existingCategory) {
            categoryMap.set(categoryData.id, existingCategory.id);
            logger.info(
              `Category ${categoryData.name} already exists, using existing`
            );
          } else if (restoreMode === "automatic") {
            const newCategory = await guild.channels.create({
              name: categoryData.name,
              type: ChannelType.GuildCategory,
              position: categoryData.position,
              reason: "Restore from backup",
            });
            categoryMap.set(categoryData.id, newCategory.id);
            logger.info(`Created category: ${categoryData.name}`);
          } else {
            logger.info(
              `Skipping category creation for ${categoryData.name} (manual mode)`
            );
          }
        } catch (error) {
          logger.warn(
            `Failed to restore category ${categoryData.name}:`,
            error.message
          );
        }
      }

      for (const channelData of sortedChannels) {
        try {
          const mappedParentId = channelData.parentId
            ? categoryMap.get(channelData.parentId)
            : null;

          const existingChannel = guild.channels.cache.find(
            (c) =>
              c.name === channelData.name &&
              c.type === channelData.type &&
              c.parentId === mappedParentId
          );

          if (existingChannel) {
            try {
              await existingChannel.edit({
                name: channelData.name,
                topic: channelData.topic,
                nsfw: channelData.nsfw,
                bitrate: channelData.bitrate,
                userLimit: channelData.userLimit,
                reason: "Restore from backup",
              });

              if (channelData.permissionOverwrites) {
                for (const overwrite of channelData.permissionOverwrites) {
                  try {
                    await existingChannel.permissionOverwrites.edit(
                      overwrite.id,
                      {
                        allow: overwrite.allow,
                        deny: overwrite.deny,
                      }
                    );
                  } catch (error) {
                    logger.warn(
                      `Failed to restore permission for ${channelData.name}:`,
                      error.message
                    );
                  }
                }
              }
              logger.info(`Updated existing channel: ${channelData.name}`);
            } catch (error) {
              logger.warn(
                `Failed to update channel ${channelData.name}:`,
                error.message
              );
            }
          } else if (restoreMode === "automatic") {
            const channelOptions = {
              name: channelData.name,
              type: channelData.type,
              parent: mappedParentId,
              topic: channelData.topic,
              nsfw: channelData.nsfw,
              bitrate: channelData.bitrate,
              userLimit: channelData.userLimit,
              position: channelData.position,
              reason: "Restore from backup",
            };

            const newChannel = await guild.channels.create(channelOptions);

            if (channelData.permissionOverwrites) {
              for (const overwrite of channelData.permissionOverwrites) {
                try {
                  await newChannel.permissionOverwrites.edit(overwrite.id, {
                    allow: overwrite.allow,
                    deny: overwrite.deny,
                  });
                } catch (error) {
                  logger.warn(
                    `Failed to restore permission for ${channelData.name}:`,
                    error.message
                  );
                }
              }
            }
            logger.info(`Created channel: ${channelData.name}`);
          } else {
            logger.info(
              `Skipping channel creation for ${channelData.name} (manual mode)`
            );
          }
        } catch (error) {
          logger.warn(
            `Failed to restore channel ${channelData.name}:`,
            error.message
          );
        }
      }
    } catch (error) {
      logger.error("Restore channels error:", error);
      throw error;
    }
  }

  async restoreEmojis(guild, emojis) {
    try {
      await guild.emojis.fetch();

      for (const emojiData of emojis) {
        try {
          const existingEmoji = guild.emojis.cache.find(
            (e) => e.name === emojiData.name
          );
          if (!existingEmoji) {
            const response = await fetch(emojiData.url);
            if (!response.ok) {
              throw new Error(
                `Failed to fetch emoji image: ${response.status}`
              );
            }
            const buffer = await response.arrayBuffer();
            await guild.emojis.create({
              attachment: Buffer.from(buffer),
              name: emojiData.name,
              reason: "Restore from backup",
            });
            logger.info(`Restored emoji: ${emojiData.name}`);
          } else {
            logger.info(`Emoji ${emojiData.name} already exists, skipping`);
          }
        } catch (error) {
          logger.warn(
            `Failed to restore emoji ${emojiData.name}:`,
            error.message
          );
        }
      }
    } catch (error) {
      logger.error("Restore emojis error:", error);
      throw error;
    }
  }

  async restoreStickers(guild, stickers) {
    try {
      await guild.stickers.fetch();

      for (const stickerData of stickers) {
        try {
          const existingSticker = guild.stickers.cache.find(
            (s) => s.name === stickerData.name
          );
          if (!existingSticker) {
            const response = await fetch(stickerData.url);
            if (!response.ok) {
              throw new Error(
                `Failed to fetch sticker image: ${response.status}`
              );
            }
            const buffer = await response.arrayBuffer();
            await guild.stickers.create({
              file: Buffer.from(buffer),
              name: stickerData.name,
              description: stickerData.description || stickerData.name,
              tags: stickerData.name,
              reason: "Restore from backup",
            });
            logger.info(`Restored sticker: ${stickerData.name}`);
          } else {
            logger.info(`Sticker ${stickerData.name} already exists, skipping`);
          }
        } catch (error) {
          logger.warn(
            `Failed to restore sticker ${stickerData.name}:`,
            error.message
          );
        }
      }
    } catch (error) {
      logger.error("Restore stickers error:", error);
      throw error;
    }
  }

  async restoreMembers(guild, members) {
    try {
      // Get OAuth tokens for members
      const userIds = members.map((m) => m.id);
      const tokens = await OAuthToken.find({ userId: { $in: userIds } });

      for (const memberData of members) {
        try {
          const tokenDoc = tokens.find((t) => t.userId === memberData.id);
          if (!tokenDoc) {
            logger.warn(`No OAuth token found for user ${memberData.id}`);
            continue;
          }

          // Decrypt token
          let accessToken = EncryptionService.decrypt(tokenDoc.encryptedToken);

          // Check if token is expired
          if (tokenDoc.expiresAt < new Date()) {
            // Try to refresh token
            const refreshToken = EncryptionService.decrypt(
              tokenDoc.encryptedRefreshToken
            );
            const newTokens = await OAuth2Service.refreshToken(refreshToken);

            // Update token in database
            tokenDoc.encryptedToken = EncryptionService.encrypt(
              newTokens.access_token
            );
            tokenDoc.encryptedRefreshToken = EncryptionService.encrypt(
              newTokens.refresh_token
            );
            tokenDoc.expiresAt = new Date(
              Date.now() + newTokens.expires_in * 1000
            );
            await tokenDoc.save();

            accessToken = newTokens.access_token;
          }

          // Join user to guild
          await OAuth2Service.joinGuild(guild.id, memberData.id, accessToken);

          // Restore roles
          if (memberData.roles && memberData.roles.length > 0) {
            const member = await guild.members.fetch(memberData.id);
            const roles = memberData.roles
              .map((roleId) => guild.roles.cache.get(roleId))
              .filter((role) => role && role.id !== guild.id);

            if (roles.length > 0) {
              await member.roles.set(roles, "Restore from backup");
            }
          }

          // Restore nickname
          if (memberData.nickname) {
            const member = await guild.members.fetch(memberData.id);
            await member.setNickname(
              memberData.nickname,
              "Restore from backup"
            );
          }
        } catch (error) {
          logger.warn(
            `Failed to restore member ${memberData.id}:`,
            error.message
          );
        }
      }
    } catch (error) {
      logger.error("Restore members error:", error);
      throw error;
    }
  }

  getRestoreStatus(restoreId) {
    return restoreStatuses.get(restoreId) || null;
  }
}

export default new RestoreService();
