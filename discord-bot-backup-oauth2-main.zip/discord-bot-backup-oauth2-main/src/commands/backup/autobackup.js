import { EmbedBuilder, StringSelectMenuBuilder, ActionRowBuilder, StringSelectMenuOptionBuilder, ButtonBuilder, ButtonStyle, MessageFlags } from 'discord.js';
import SchedulerService from '../../services/SchedulerService.js';

export default {
  name: 'autobackup',
  description: 'Configurar backups automáticos',
  category: 'backup',
  userPermissions: ['Administrator'],
  async execute(interaction) {
    try {

      // Check if auto-backup already exists
      const existing = await SchedulerService.getAutoBackup(interaction.guild.id);

      if (existing && existing.enabled) {
        const componentLabels = {
          serverSettings: "⚙️ Configurações do Servidor",
          channels: "📁 Canais",
          roles: "👑 Cargos",
          members: "👥 Membros",
          messages: "💬 Mensagens",
          emojis: "😀 Emojis",
          stickers: "🎨 Stickers",
          permissions: "🔐 Permissões",
        };

        const componentList = existing.components 
          ? Object.keys(existing.components)
              .filter(key => existing.components[key])
              .map(key => componentLabels[key] || key)
              .join("\n")
          : "Todos";

        const embed = new EmbedBuilder()
          .setTitle('🤖 Backup Automático Ativo')
          .setDescription(
            `**Intervalo:** ${this.formatInterval(existing.interval)}\n` +
            `**Próximo Backup:** <t:${Math.floor(existing.nextBackup.getTime() / 1000)}:R>\n` +
            `**Último Backup:** ${existing.lastBackup ? `<t:${Math.floor(existing.lastBackup.getTime() / 1000)}:R>` : 'Nunca'}\n\n` +
            `**Componentes:**\n${componentList}`
          )
          .setColor(0x43b581)
          .setTimestamp();

        const disableButton = new ButtonBuilder()
          .setCustomId('autobackup_disable')
          .setLabel('Desativar Backup Automático')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('🛑');

        const row = new ActionRowBuilder().addComponents(disableButton);

        return await interaction.reply({ embeds: [embed], components: [row], flags: MessageFlags.Ephemeral });
      }

      // Show interval selection menu
      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('autobackup_interval')
        .setPlaceholder('Selecione o intervalo para backups automáticos')
        .addOptions(
          new StringSelectMenuOptionBuilder()
            .setLabel('1 Semana')
            .setDescription('Backup a cada 7 dias')
            .setValue('1week')
            .setEmoji('📅'),
          new StringSelectMenuOptionBuilder()
            .setLabel('2 Semanas')
            .setDescription('Backup a cada 14 dias')
            .setValue('2weeks')
            .setEmoji('📆'),
          new StringSelectMenuOptionBuilder()
            .setLabel('3 Semanas')
            .setDescription('Backup a cada 21 dias')
            .setValue('3weeks')
            .setEmoji('🗓️'),
          new StringSelectMenuOptionBuilder()
            .setLabel('1 Mês')
            .setDescription('Backup a cada 30 dias')
            .setValue('1month')
            .setEmoji('📆')
        );

      const row = new ActionRowBuilder().addComponents(selectMenu);

      await interaction.reply({
        content: '🤖 **Configurar Backup Automático**\n\nSelecione o intervalo desejado:',
        components: [row],
        flags: MessageFlags.Ephemeral
      });
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral
      });
    }
  },

  formatInterval(interval) {
    const intervals = {
      '1week': '1 Semana',
      '2weeks': '2 Semanas',
      '3weeks': '3 Semanas',
      '1month': '1 Mês'
    };
    return intervals[interval] || interval;
  }
};
