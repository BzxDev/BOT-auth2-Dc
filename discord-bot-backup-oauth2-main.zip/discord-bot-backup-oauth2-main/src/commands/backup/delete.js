import {
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import BackupService from "../../services/BackupService.js";

export default {
  name: "deletar",
  description: "Deletar um backup",
  category: "backup",
  userPermissions: ["Administrator"],
  async execute(interaction) {
    try {
      const guildId = interaction.guild.id;

      // Buscar backups disponíveis
      const { backups, total } = await BackupService.listBackups(guildId, 25);

      if (backups.length === 0) {
        return await interaction.reply({
          content:
            "📭 Nenhum backup encontrado para este servidor.\n\nUse `/backup criar` para criar um backup primeiro.",
          flags: MessageFlags.Ephemeral,
        });
      }

      // Criar menu de seleção de backups
      const options = backups.map((backup) => {
        const date = new Date(backup.createdAt);
        const dateStr = date.toLocaleDateString("pt-BR", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        });
        const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
        const typeEmoji = backup.isAutoBackup ? "🤖" : "💾";

        return new StringSelectMenuOptionBuilder()
          .setLabel(`${typeEmoji} ${backup.name}`)
          .setDescription(`${dateStr} • ${sizeMB} MB`)
          .setValue(backup._id.toString());
      });

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId("backup_delete_select")
        .setPlaceholder("Selecione o backup para deletar")
        .addOptions(options);

      const row = new ActionRowBuilder().addComponents(selectMenu);

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Deletar Backup")
        .setDescription(
          `**Total:** ${total} backup(s)\n\n` +
            `⚠️ **Atenção:** Esta ação não pode ser desfeita!\n\n` +
            `Selecione o backup que deseja deletar abaixo.`
        )
        .setColor(0xf04747)
        .setFooter({ text: "Backup - Backup Bot" })
        .setTimestamp();

      await interaction.reply({
        embeds: [embed],
        components: [row],
        flags: MessageFlags.Ephemeral,
      });
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
