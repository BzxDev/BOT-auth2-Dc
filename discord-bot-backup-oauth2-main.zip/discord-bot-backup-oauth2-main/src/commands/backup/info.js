import {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} from "discord.js";
import BackupService from "../../services/BackupService.js";

export default {
  name: "info",
  description: "Ver informações detalhadas de um backup",
  category: "backup",
  userPermissions: ["Administrator"],
  async execute(interaction) {
    try {
      // Se não tiver backup_id, mostrar menu de seleção
      const backupId = interaction.options.getString("backup_id", false);

      if (!backupId) {
        const guildId = interaction.guild.id;
        const { backups } = await BackupService.listBackups(guildId, 25);

        if (backups.length === 0) {
          return await interaction.reply({
            content:
              "📭 Nenhum backup encontrado para este servidor.\n\nUse `/backup criar` para criar um backup primeiro.",
            flags: MessageFlags.Ephemeral,
          });
        }

        const {
          StringSelectMenuBuilder,
          StringSelectMenuOptionBuilder,
        } = await import("discord.js");

        const options = backups.map((backup) => {
          const date = new Date(backup.createdAt);
          const dateStr = date.toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          });
          const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
          const typeEmoji = backup.isAutoBackup ? "🤖" : "💾";

          return new StringSelectMenuOptionBuilder()
            .setLabel(`${typeEmoji} ${backup.name}`)
            .setDescription(`${dateStr} • ${sizeMB} MB`)
            .setValue(backup._id.toString());
        });

        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId("backup_info_select")
          .setPlaceholder("Selecione um backup para ver informações")
          .addOptions(options);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        const embed = new EmbedBuilder()
          .setTitle("📦 Selecionar Backup")
          .setDescription("Selecione um backup para ver informações detalhadas.")
          .setColor(0x5865f2)
          .setFooter({ text: "Backup - Backup Bot" })
          .setTimestamp();

        return await interaction.reply({
          embeds: [embed],
          components: [row],
          flags: MessageFlags.Ephemeral,
        });
      }

      const backup = await BackupService.getBackup(backupId);

      if (backup.guildId !== interaction.guild.id) {
        return await interaction.reply({
          content: "❌ Este backup não pertence a este servidor.",
          flags: MessageFlags.Ephemeral,
        });
      }

      const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
      const components = Object.entries(backup.includedComponents)
        .filter(([_, included]) => included)
        .map(([key]) => {
          const names = {
            serverSettings: "⚙️ Configurações do Servidor",
            channels: "📁 Canais",
            roles: "👑 Cargos",
            members: "👥 Membros",
            messages: "💬 Mensagens",
            emojis: "😀 Emojis",
            stickers: "🎨 Stickers",
            permissions: "🔐 Permissões",
          };
          return names[key] || key;
        });

      const embed = new EmbedBuilder()
        .setTitle(`📦 Informações do Backup: ${backup.name}`)
        .addFields(
          { name: "ID", value: `\`${backup._id}\``, inline: true },
          { name: "Tamanho", value: `${sizeMB} MB`, inline: true },
          {
            name: "Comprimido",
            value: backup.compressed ? "Sim" : "Não",
            inline: true,
          },
          {
            name: "Tipo",
            value: backup.isAutoBackup ? "🤖 Automático" : "💾 Manual",
            inline: true,
          },
          {
            name: "Criado por",
            value: `<@${backup.createdBy}>`,
            inline: true,
          },
          {
            name: "Criado em",
            value: `<t:${Math.floor(backup.createdAt.getTime() / 1000)}:F>`,
            inline: true,
          },
          {
            name: "Componentes Incluídos",
            value: components.length > 0 ? components.join("\n") : "Nenhum",
            inline: false,
          }
        )
        .setColor(0x5865f2)
        .setFooter({ text: "Backup - Backup Bot" })
        .setTimestamp();

      if (backup.metadata) {
        embed.addFields(
          {
            name: "Membros",
            value: backup.metadata.memberCount?.toString() || "0",
            inline: true,
          },
          {
            name: "Canais",
            value: backup.metadata.channelCount?.toString() || "0",
            inline: true,
          },
          {
            name: "Cargos",
            value: backup.metadata.roleCount?.toString() || "0",
            inline: true,
          },
          {
            name: "Mensagens",
            value: backup.metadata.messageCount?.toString() || "0",
            inline: true,
          }
        );
      }

      const restoreButton = new ButtonBuilder()
        .setCustomId(`backup_restore_${backup._id}`)
        .setLabel("Restaurar")
        .setStyle(ButtonStyle.Success)
        .setEmoji("🔄");

      const deleteButton = new ButtonBuilder()
        .setCustomId(`backup_delete_${backup._id}`)
        .setLabel("Deletar")
        .setStyle(ButtonStyle.Danger)
        .setEmoji("🗑️");

      const listButton = new ButtonBuilder()
        .setCustomId("backup_list_back")
        .setLabel("Voltar para Lista")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("📋");

      const row = new ActionRowBuilder().addComponents(
        restoreButton,
        deleteButton,
        listButton
      );

      await interaction.reply({
        embeds: [embed],
        components: [row],
        flags: MessageFlags.Ephemeral,
      });
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
