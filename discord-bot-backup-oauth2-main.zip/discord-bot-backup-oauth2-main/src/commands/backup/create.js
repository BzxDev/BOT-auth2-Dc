import {
  EmbedBuilder,
  StringSelectMenuBuilder,
  ActionRowBuilder,
  StringSelectMenuOptionBuilder,
  MessageFlags,
} from "discord.js";
import { validateBackupName } from "../../utils/validators.js";

export default {
  name: "criar",
  description: "Criar um novo backup do servidor",
  category: "backup",
  userPermissions: ["Administrator"],
  botPermissions: ["ViewChannel", "ReadMessageHistory"],
  options: [
    {
      name: "nome",
      description: "Nome do backup",
      type: 3, // STRING
      required: false,
    },
  ],
  async execute(interaction) {
    try {
      const guild = interaction.guild;
      const backupName =
        interaction.options.getString("nome") ||
        `backup-${new Date().toISOString().split("T")[0]}`;

      validateBackupName(backupName);

      // Show component selection menu
      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId("backup_components")
        .setPlaceholder("Selecione os componentes para incluir no backup")
        .setMinValues(1)
        .setMaxValues(8)
        .addOptions(
          new StringSelectMenuOptionBuilder()
            .setLabel("Tudo")
            .setDescription("Selecionar todos os componentes")
            .setValue("all")
            .setEmoji("✅"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Configurações do Servidor")
            .setDescription("Nome, ícone, descrição, etc.")
            .setValue("serverSettings")
            .setEmoji("⚙️"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Canais")
            .setDescription("Todos os canais e suas configurações")
            .setValue("channels")
            .setEmoji("📁"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Cargos")
            .setDescription("Todos os cargos e permissões")
            .setValue("roles")
            .setEmoji("👑"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Membros")
            .setDescription("Lista de membros e seus cargos")
            .setValue("members")
            .setEmoji("👥"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Emojis")
            .setDescription("Todos os emojis personalizados")
            .setValue("emojis")
            .setEmoji("😀"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Stickers")
            .setDescription("Todos os stickers personalizados")
            .setValue("stickers")
            .setEmoji("🎨"),
          new StringSelectMenuOptionBuilder()
            .setLabel("Permissões")
            .setDescription("Permissões de canais e cargos")
            .setValue("permissions")
            .setEmoji("🔐")
        );

      const row = new ActionRowBuilder().addComponents(selectMenu);

      await interaction.reply({
        content: `📦 **Criando Backup: ${backupName}**\n\nSelecione os componentes que deseja incluir:`,
        components: [row],
        flags: MessageFlags.Ephemeral,
      });

      // Store backup name for later use
      interaction.client.backupQueue =
        interaction.client.backupQueue || new Map();
      interaction.client.backupQueue.set(interaction.user.id, {
        guildId: guild.id,
        name: backupName,
        userId: interaction.user.id,
      });
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
