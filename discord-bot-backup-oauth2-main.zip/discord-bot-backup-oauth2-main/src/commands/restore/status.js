import { EmbedBuilder, MessageFlags } from 'discord.js';
import RestoreService from '../../services/RestoreService.js';
import { validateBackupId } from '../../utils/validators.js';

export default {
  name: 'status',
  description: 'Ver status de uma restauração',
  category: 'restore',
  userPermissions: ['Administrator'],
  options: [
    {
      name: 'restore_id',
      description: 'ID da restauração',
      type: 3, // STRING
      required: true
    }
  ],
  async execute(interaction) {
    try {
      const restoreId = interaction.options.getString('restore_id');

      const status = RestoreService.getRestoreStatus(restoreId);

      if (!status) {
        return await interaction.reply({
          content: '❌ Restauração não encontrada ou já foi concluída.',
          flags: MessageFlags.Ephemeral
        });
      }

      const progressBar = this.createProgressBar(status.progress);
      const statusEmoji = {
        'in_progress': '🔄',
        'completed': '✅',
        'failed': '❌'
      }[status.status] || '⏳';

      const embed = new EmbedBuilder()
        .setTitle(`${statusEmoji} Status da Restauração`)
        .setDescription(
          `**ID:** \`${restoreId}\`\n` +
          `**Status:** ${this.formatStatus(status.status)}\n` +
          `**Progresso:** ${status.progress}%\n` +
          progressBar
        )
        .setColor(this.getStatusColor(status.status))
        .setTimestamp();

      if (status.steps.length > 0) {
        embed.addFields({
          name: 'Etapas',
          value: status.steps.map((step, index) => `${index + 1}. ${step}`).join('\n'),
          inline: false
        });
      }

      if (status.error) {
        embed.addFields({
          name: 'Erro',
          value: `\`\`\`${status.error}\`\`\``,
          inline: false
        });
      }

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral
      });
    }
  },

  createProgressBar(progress) {
    const filled = Math.round(progress / 10);
    const empty = 10 - filled;
    return `\`[${'█'.repeat(filled)}${'░'.repeat(empty)}]\``;
  },

  formatStatus(status) {
    const statuses = {
      'in_progress': 'Em Andamento',
      'completed': 'Concluída',
      'failed': 'Falhou'
    };
    return statuses[status] || status;
  },

  getStatusColor(status) {
    const colors = {
      'in_progress': 0x5865f2,
      'completed': 0x43b581,
      'failed': 0xf04747
    };
    return colors[status] || 0x99aab5;
  }
};
