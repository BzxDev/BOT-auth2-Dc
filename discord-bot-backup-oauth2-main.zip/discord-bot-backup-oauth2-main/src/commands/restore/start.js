import {
  EmbedBuilder,
  MessageFlags,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ActionRowBuilder,
} from "discord.js";
import BackupService from "../../services/BackupService.js";

export default {
  name: "iniciar",
  description: "Iniciar restauração de um backup",
  category: "restore",
  userPermissions: ["Administrator"],
  botPermissions: [
    "ManageGuild",
    "ManageChannels",
    "ManageRoles",
    "ManageNicknames",
    "ManageEmojisAndStickers",
  ],
  async execute(interaction) {
    try {
      const guildId = interaction.guild.id;

      // Buscar backups disponíveis
      const { backups, total } = await BackupService.listBackups(guildId, 25);

      if (backups.length === 0) {
        return await interaction.reply({
          content:
            "📭 Nenhum backup encontrado para este servidor.\n\nUse `/backup criar` para criar um backup primeiro.",
          flags: MessageFlags.Ephemeral,
        });
      }

      // Criar opções do menu
      const options = backups.map((backup) => {
        const date = new Date(backup.createdAt);
        const dateStr = date.toLocaleDateString("pt-BR", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        });
        const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
        const typeEmoji = backup.isAutoBackup ? "🤖" : "💾";

        return new StringSelectMenuOptionBuilder()
          .setLabel(`${typeEmoji} ${backup.name}`)
          .setDescription(`${dateStr} • ${sizeMB} MB`)
          .setValue(backup._id.toString());
      });

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId("restore_backup_select")
        .setPlaceholder("Selecione o backup para restaurar")
        .addOptions(options);

      const row = new ActionRowBuilder().addComponents(selectMenu);

      const embed = new EmbedBuilder()
        .setTitle("🔄 Restaurar Backup")
        .setDescription(
          `Selecione um backup para restaurar.\n\n` +
            `**Total de backups:** ${total}\n` +
            `**Mostrando:** ${backups.length} mais recentes\n\n` +
            `⚠️ **Atenção:** A restauração irá modificar o servidor atual.`
        )
        .setColor(0x5865f2)
        .setFooter({ text: "Restauração - Backup Bot" })
        .setTimestamp();

      await interaction.reply({
        embeds: [embed],
        components: [row],
        flags: MessageFlags.Ephemeral,
      });

      // Salvar contexto para o handler
      interaction.client.restoreQueue =
        interaction.client.restoreQueue || new Map();
      interaction.client.restoreQueue.set(interaction.user.id, {
        guildId: interaction.guild.id,
        userId: interaction.user.id,
      });
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
