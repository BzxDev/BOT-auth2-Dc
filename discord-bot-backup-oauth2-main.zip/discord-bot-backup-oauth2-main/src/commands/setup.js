import {
  EmbedBuilder,
  ChannelSelectMenuBuilder,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import GuildConfig from "../database/models/GuildConfig.js";
import logger from "../utils/logger.js";

export default {
  name: "setup",
  description: "Configurar o bot de backup",
  category: "setup",
  userPermissions: ["Administrator"],
  botPermissions: ["SendMessages", "EmbedLinks"],
  options: [
    {
      name: "tipo",
      description: "Tipo de configuração de restauração",
      type: 3, // STRING
      required: true,
      choices: [
        {
          name: "Automático - Criar todos os canais",
          value: "automatic",
        },
        {
          name: "Manual - Apenas configurar canais existentes",
          value: "manual",
        },
      ],
    },
  ],
  async execute(interaction) {
    try {
      const tipo = interaction.options.getString("tipo");
      const guildId = interaction.guild.id;
      const userId = interaction.user.id;

      // Normalizar o valor (trim e lowercase para garantir)
      const normalizedTipo = tipo?.trim().toLowerCase();

      // Verificar se é automático (aceita "automatic" ou "auto" - Discord pode retornar valores truncados)
      const isAutomatic =
        normalizedTipo === "automatic" || normalizedTipo === "auto";

      if (isAutomatic) {
        // Fluxo Automático: Salva configuração e confirma
        await GuildConfig.findOneAndUpdate(
          { guildId },
          {
            guildId,
            channelRestoreMode: "automatic",
            updatedBy: userId,
            updatedAt: new Date(),
          },
          { upsert: true, new: true }
        );

        const embed = new EmbedBuilder()
          .setTitle("✅ Configuração Atualizada")
          .setDescription(
            `**Tipo de Restauração:** 🤖 Automático - Criar todos os canais\n\n` +
              `A configuração foi salva com sucesso. Esta configuração será aplicada em todas as restaurações futuras deste servidor.`
          )
          .setColor(0x43b581)
          .setFooter({ text: "Configuração de Restauração - Backup Bot" })
          .setTimestamp();

        await interaction.reply({
          embeds: [embed],
          flags: MessageFlags.Ephemeral,
        });
      } else {
        // Fluxo Manual: Salva configuração e pergunta canal para OAuth2
        await GuildConfig.findOneAndUpdate(
          { guildId },
          {
            guildId,
            channelRestoreMode: "manual",
            updatedBy: userId,
            updatedAt: new Date(),
          },
          { upsert: true, new: true }
        );

        const embed = new EmbedBuilder()
          .setTitle("⚙️ Configuração Manual")
          .setDescription(
            `**Tipo de Restauração:** ✋ Manual - Apenas configurar canais existentes\n\n` +
              `Para coletar tokens OAuth2 dos membros e permitir restauração após raids/mass bans, selecione o canal onde deseja enviar a embed de autorização OAuth2.\n\n` +
              `**Como funciona:**\n` +
              `1. Selecione um canal abaixo\n` +
              `2. Uma embed será enviada no canal escolhido\n` +
              `3. Membros clicam no botão para autorizar\n` +
              `4. Tokens são armazenados com segurança (criptografados)\n` +
              `5. Em caso de raid/mass ban, o bot pode restaurar os membros`
          )
          .setColor(0x5865f2)
          .setFooter({ text: "Configuração Manual - Backup Bot" })
          .setTimestamp();

        const channelSelect = new ChannelSelectMenuBuilder()
          .setCustomId("setup_oauth2_channel")
          .setPlaceholder("Selecione o canal para enviar a embed OAuth2")
          .setMinValues(1)
          .setMaxValues(1);

        const row = new ActionRowBuilder().addComponents(channelSelect);

        await interaction.reply({
          embeds: [embed],
          components: [row],
          flags: MessageFlags.Ephemeral,
        });
      }
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
