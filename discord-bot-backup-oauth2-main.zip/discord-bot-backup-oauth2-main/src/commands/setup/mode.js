import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import GuildConfig from "../../database/models/GuildConfig.js";

export default {
  name: "modo",
  description: "Alterar o modo de restauração (Automático ou Manual)",
  category: "setup",
  userPermissions: ["Administrator"],
  botPermissions: ["SendMessages", "EmbedLinks"],
  async execute(interaction) {
    try {
      const guildId = interaction.guild.id;

      // Buscar configuração atual
      const currentConfig = await GuildConfig.findOne({ guildId });
      const currentMode = currentConfig?.channelRestoreMode || "automatic";

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Modo de Restauração")
        .setDescription(
          `**Modo Atual:** ${
            currentMode === "automatic"
              ? "🤖 Automático - Criar todos os canais"
              : "✋ Manual - Apenas configurar canais existentes"
          }\n\n` +
            `Selecione o modo desejado abaixo para alterar a configuração.\n\n` +
            `**🤖 Automático:** O bot criará todos os canais durante a restauração.\n` +
            `**✋ Manual:** O bot apenas configurará canais existentes. Requer tokens OAuth2 para restaurar membros.`
        )
        .setColor(0x5865f2)
        .setFooter({ text: "Configuração de Restauração - Backup Bot" })
        .setTimestamp();

      const automaticButton = new ButtonBuilder()
        .setCustomId("setup_mode_automatic")
        .setLabel("Automático")
        .setStyle(
          currentMode === "automatic"
            ? ButtonStyle.Success
            : ButtonStyle.Primary
        )
        .setEmoji("🤖")
        .setDisabled(currentMode === "automatic");

      const manualButton = new ButtonBuilder()
        .setCustomId("setup_mode_manual")
        .setLabel("Manual")
        .setStyle(
          currentMode === "manual" ? ButtonStyle.Success : ButtonStyle.Primary
        )
        .setEmoji("✋")
        .setDisabled(currentMode === "manual");

      const row = new ActionRowBuilder().addComponents(
        automaticButton,
        manualButton
      );

      await interaction.reply({
        embeds: [embed],
        components: [row],
        flags: MessageFlags.Ephemeral,
      });
    } catch (error) {
      await interaction.reply({
        content: `❌ Erro: ${error.message}`,
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
