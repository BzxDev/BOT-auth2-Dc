import { EmbedBuilder } from 'discord.js';

const commands = {
  backup: [
    { name: '/backup criar', description: 'Criar um novo backup do servidor' },
    { name: '/backup listar', description: 'Listar todos os backups' },
    { name: '/backup info', description: 'Ver informações de um backup' },
    { name: '/backup deletar', description: 'Deletar um backup' },
    { name: '/backup autobackup', description: 'Configurar backups automáticos' }
  ],
  restore: [
    { name: '/restore iniciar', description: 'Iniciar restauração de um backup' },
    { name: '/restore status', description: 'Ver status de uma restauração' }
  ],
  setup: [
    { name: '/setup', description: 'Configurar o bot de backup (Automático ou Manual)' }
  ],
  utility: [
    { name: '/ping', description: 'Verificar latência do bot' },
    { name: '/help', description: 'Ver esta lista de comandos' }
  ]
};

export default {
  name: 'help',
  description: 'Lista de comandos disponíveis',
  category: 'utility',
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('📚 Comandos Disponíveis')
      .setDescription('Lista de todos os comandos do bot de backup')
      .setColor(0x5865f2)
      .setTimestamp();

    for (const [category, cmds] of Object.entries(commands)) {
      const categoryName = {
        backup: '💾 Backup',
        restore: '🔄 Restauração',
        setup: '⚙️ Configuração',
        utility: '🛠️ Utilidades'
      }[category];

      embed.addFields({
        name: categoryName,
        value: cmds.map(cmd => `\`${cmd.name}\` - ${cmd.description}`).join('\n'),
        inline: false
      });
    }

    embed.setFooter({ text: 'Bot de Backup OAuth2' });

    await interaction.reply({ embeds: [embed] });
  }
};
