import { EmbedBuilder } from 'discord.js';

export default {
  name: 'ping',
  description: 'Verificar latência do bot',
  category: 'utility',
  async execute(interaction) {
    const sent = await interaction.reply({
      content: '🏓 Pinging...',
      fetchReply: true
    });

    const latency = sent.createdTimestamp - interaction.createdTimestamp;
    const apiLatency = Math.round(interaction.client.ws.ping);

    const embed = new EmbedBuilder()
      .setTitle('🏓 Pong!')
      .addFields(
        { name: 'Latência do Bot', value: `${latency}ms`, inline: true },
        { name: 'Latência da API', value: `${apiLatency}ms`, inline: true }
      )
      .setColor(0x43b581)
      .setTimestamp();

    await interaction.editReply({
      content: '',
      embeds: [embed]
    });
  }
};
