import { MessageFlags, EmbedBuilder } from "discord.js";
import {
  requireAdmin,
  checkBotPermissions,
  checkUserPermissions,
  formatMissingPermissions,
} from "../utils/permissions.js";
import logger from "../utils/logger.js";
import { ADMIN_CATEGORIES } from "./interactions/constants.js";
import { handleComponentInteraction } from "./interactions/index.js";

function buildSubcommandList(commandName, subcommands) {
  const categoryDisplay =
    commandName.charAt(0).toUpperCase() + commandName.slice(1);

  const subcommandLines = subcommands.map(
    (cmd) => `\`/${commandName} ${cmd.name}\` - ${cmd.description}`
  );

  return { categoryDisplay, subcommandList: subcommandLines.join("\n") };
}

function findSubcommandsByCategory(client, category) {
  const subcommands = [];
  for (const [name, cmd] of client.commands) {
    if (cmd.category === category) {
      subcommands.push({
        name,
        description: cmd.description || "Sem descrição",
      });
    }
  }
  return subcommands;
}

async function handleSlashCommand(interaction, client) {
  if (!interaction.isChatInputCommand()) return;

  try {
    const commandName = interaction.commandName;
    const subcommandName = interaction.options.getSubcommand(false);

    let command;
    if (subcommandName) {
      command = client.commands.get(subcommandName);
    } else {
      command = client.commands.get(commandName);
    }

    if (!command) {
      const subcommands = findSubcommandsByCategory(client, commandName);

      if (subcommands.length > 0) {
        const { categoryDisplay, subcommandList } = buildSubcommandList(
          commandName,
          subcommands
        );

        const content = subcommandName
          ? `❌ Subcomando \`${subcommandName}\` não encontrado em \`/${commandName}\`.\n\n` +
            `**Subcomandos disponíveis:**\n${subcommandList}\n\n` +
            `Use um dos subcomandos acima para executar o comando.`
          : `**${categoryDisplay}**\n\n` +
            `**Subcomandos disponíveis:**\n${subcommandList}\n\n` +
            `Use \`/${commandName} <subcomando>\` para executar um comando.`;

        return await interaction.reply({
          content,
          flags: MessageFlags.Ephemeral,
        });
      }

      return await interaction.reply({
        content: "❌ Comando não encontrado.",
        flags: MessageFlags.Ephemeral,
      });
    }

    if (command.botPermissions && command.botPermissions.length > 0) {
      const botCheck = checkBotPermissions(interaction, command.botPermissions);
      if (!botCheck.hasAll) {
        const embed = new EmbedBuilder()
          .setTitle("❌ Permissões Insuficientes do Bot")
          .setDescription(
            `O bot não tem as permissões necessárias para executar este comando.\n\n` +
              `**Permissões faltando:**\n${formatMissingPermissions(botCheck.missing)}\n\n` +
              `Por favor, verifique as permissões do bot no servidor.`
          )
          .setColor(0xf04747)
          .setFooter({ text: "Erro de Permissão - Backup Bot" })
          .setTimestamp();

        return await interaction.reply({
          embeds: [embed],
          flags: MessageFlags.Ephemeral,
        });
      }
    }

    if (command.userPermissions && command.userPermissions.length > 0) {
      const userCheck = checkUserPermissions(
        interaction,
        command.userPermissions
      );
      if (!userCheck.hasAll) {
        const embed = new EmbedBuilder()
          .setTitle("❌ Permissões Insuficientes")
          .setDescription(
            `Você não tem as permissões necessárias para executar este comando.\n\n` +
              `**Permissões necessárias:**\n${formatMissingPermissions(userCheck.missing)}`
          )
          .setColor(0xf04747)
          .setFooter({ text: "Erro de Permissão - Backup Bot" })
          .setTimestamp();

        return await interaction.reply({
          embeds: [embed],
          flags: MessageFlags.Ephemeral,
        });
      }
    }

    if (
      ADMIN_CATEGORIES.includes(command.category) &&
      !command.userPermissions
    ) {
      try {
        requireAdmin(interaction);
      } catch (error) {
        return await interaction.reply({
          content: `❌ ${error.message}`,
          flags: MessageFlags.Ephemeral,
        });
      }
    }

    await command.execute(interaction);
  } catch (error) {
    logger.error("Command execution error:", error);
    const reply =
      interaction.replied || interaction.deferred
        ? interaction.followUp.bind(interaction)
        : interaction.reply.bind(interaction);

    await reply({
      content: `❌ Ocorreu um erro ao executar o comando: ${error.message}`,
      flags: MessageFlags.Ephemeral,
    }).catch(() => {});
  }
}

export async function handleCommand(interaction, client) {
  if (interaction.isChatInputCommand()) {
    return await handleSlashCommand(interaction, client);
  }

  if (interaction.isButton() || interaction.isAnySelectMenu()) {
    return await handleComponentInteraction(interaction, client);
  }
}
