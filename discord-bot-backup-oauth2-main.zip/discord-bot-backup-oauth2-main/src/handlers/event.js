import { Events } from "discord.js";
import logger from "../utils/logger.js";
import { handleCommand } from "./command.js";
import { connectDatabase } from "../database/connection.js";
import SchedulerService from "../services/SchedulerService.js";
import WebServer from "../structures/WebServer.js";

export const ready = async (client) => {
  logger.info(`Bot logged in as ${client.user.tag}`);

  await connectDatabase();

  await client.loadCommands();
  await client.registerSlashCommands();

  await SchedulerService.loadAllSchedules(client);

  client.webServer = new WebServer(client);
  await client.webServer.start();

  logger.info("Bot is ready!");
};

export const interactionCreate = async (interaction, client) => {
  await handleCommand(interaction, client);
};

export const error = async (error, client) => {
  logger.error("Discord client error:", error);
};

export default {
  [Events.ClientReady]: ready,
  [Events.InteractionCreate]: interactionCreate,
  [Events.Error]: error,
};
