import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import BackupService from "../../../services/BackupService.js";

const COMPONENT_NAMES = {
  serverSettings: "⚙️ Configurações do Servidor",
  channels: "📁 Canais",
  roles: "👑 Cargos",
  members: "👥 Membros",
  messages: "💬 Mensagens",
  emojis: "😀 Emojis",
  stickers: "🎨 Stickers",
  permissions: "🔐 Permissões",
};

async function buildBackupInfoEmbed(backup) {
  const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
  const components = Object.entries(backup.includedComponents)
    .filter(([_, included]) => included)
    .map(([key]) => COMPONENT_NAMES[key] || key);

  const embed = new EmbedBuilder()
    .setTitle(`📦 Informações do Backup: ${backup.name}`)
    .addFields(
      { name: "ID", value: `\`${backup._id}\``, inline: true },
      { name: "Tamanho", value: `${sizeMB} MB`, inline: true },
      {
        name: "Comprimido",
        value: backup.compressed ? "Sim" : "Não",
        inline: true,
      },
      {
        name: "Tipo",
        value: backup.isAutoBackup ? "🤖 Automático" : "💾 Manual",
        inline: true,
      },
      {
        name: "Criado por",
        value: `<@${backup.createdBy}>`,
        inline: true,
      },
      {
        name: "Criado em",
        value: `<t:${Math.floor(backup.createdAt.getTime() / 1000)}:F>`,
        inline: true,
      },
      {
        name: "Componentes Incluídos",
        value: components.length > 0 ? components.join("\n") : "Nenhum",
        inline: false,
      }
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  if (backup.metadata) {
    embed.addFields(
      {
        name: "Membros",
        value: backup.metadata.memberCount?.toString() || "0",
        inline: true,
      },
      {
        name: "Canais",
        value: backup.metadata.channelCount?.toString() || "0",
        inline: true,
      },
      {
        name: "Cargos",
        value: backup.metadata.roleCount?.toString() || "0",
        inline: true,
      },
      {
        name: "Mensagens",
        value: backup.metadata.messageCount?.toString() || "0",
        inline: true,
      }
    );
  }

  return embed;
}

export async function handleBackupInfo(interaction, backupId) {
  const backup = await BackupService.getBackup(backupId);

  if (backup.guildId !== interaction.guild.id) {
    return await interaction.reply({
      content: "❌ Este backup não pertence a este servidor.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const embed = await buildBackupInfoEmbed(backup);

  const restoreButton = new ButtonBuilder()
    .setCustomId(`backup_restore_${backup._id}`)
    .setLabel("Restaurar")
    .setStyle(ButtonStyle.Success)
    .setEmoji("🔄");

  const deleteButton = new ButtonBuilder()
    .setCustomId(`backup_delete_${backup._id}`)
    .setLabel("Deletar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("🗑️");

  const row = new ActionRowBuilder().addComponents(restoreButton, deleteButton);

  await interaction.reply({
    embeds: [embed],
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleBackupInfoSelect(interaction) {
  const backupId = interaction.values[0];
  const backup = await BackupService.getBackup(backupId);

  if (backup.guildId !== interaction.guild.id) {
    return await interaction.reply({
      content: "❌ Este backup não pertence a este servidor.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const embed = await buildBackupInfoEmbed(backup);

  const restoreButton = new ButtonBuilder()
    .setCustomId(`backup_restore_${backup._id}`)
    .setLabel("Restaurar")
    .setStyle(ButtonStyle.Success)
    .setEmoji("🔄");

  const deleteButton = new ButtonBuilder()
    .setCustomId(`backup_delete_${backup._id}`)
    .setLabel("Deletar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("🗑️");

  const listButton = new ButtonBuilder()
    .setCustomId("backup_list_back")
    .setLabel("Voltar para Lista")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("📋");

  const row = new ActionRowBuilder().addComponents(
    restoreButton,
    deleteButton,
    listButton
  );

  await interaction.update({
    embeds: [embed],
    components: [row],
  });
}
