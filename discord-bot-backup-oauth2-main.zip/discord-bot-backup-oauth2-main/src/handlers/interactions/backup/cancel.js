export async function handleBackupCancel(interaction, client) {
  client.backupQueue?.delete(interaction.user.id);

  await interaction.update({
    content: "❌ Criação de backup cancelada.",
    embeds: [],
    components: [],
  });
}
