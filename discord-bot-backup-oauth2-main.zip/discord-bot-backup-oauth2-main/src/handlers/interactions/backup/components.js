import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import {
  processSelectedComponents,
  formatComponentList,
} from "../constants.js";

export async function handleBackupComponents(interaction, client) {
  const queue = client.backupQueue.get(interaction.user.id);
  if (!queue) {
    return await interaction.reply({
      content: "❌ Sessão de backup expirada. Execute o comando novamente.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const selectedComponents = processSelectedComponents(interaction.values);
  queue.components = selectedComponents;
  client.backupQueue.set(interaction.user.id, queue);

  const componentList = formatComponentList(selectedComponents);

  const embed = new EmbedBuilder()
    .setTitle("📦 Confirmar Backup")
    .setDescription(
      `**Nome:** ${queue.name}\n\n` +
        `**Componentes selecionados:**\n${componentList}\n\n` +
        `Clique em **Confirmar** para criar o backup.`
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  const confirmButton = new ButtonBuilder()
    .setCustomId("backup_confirm")
    .setLabel("Confirmar")
    .setStyle(ButtonStyle.Success)
    .setEmoji("✅");

  const cancelButton = new ButtonBuilder()
    .setCustomId("backup_cancel")
    .setLabel("Cancelar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("❌");

  const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

  await interaction.update({
    content: "",
    embeds: [embed],
    components: [row],
  });
}
