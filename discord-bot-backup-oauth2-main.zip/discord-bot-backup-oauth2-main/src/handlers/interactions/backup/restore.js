import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import RestoreService from "../../../services/RestoreService.js";
import BackupService from "../../../services/BackupService.js";

export async function handleBackupRestore(interaction, backupId, client) {
  const backup = await BackupService.getBackup(backupId);

  if (backup.guildId !== interaction.guild.id) {
    return await interaction.reply({
      content: "❌ Este backup não pertence a este servidor.",
      flags: MessageFlags.Ephemeral,
    });
  }

  client.restoreQueue = client.restoreQueue || new Map();
  client.restoreQueue.set(interaction.user.id, {
    guildId: interaction.guild.id,
    userId: interaction.user.id,
    backupId: backupId,
  });

  const loadingEmbed = new EmbedBuilder()
    .setTitle("⏳ Iniciando Restauração...")
    .setDescription(
      `**Backup:** ${backup.name}\n\n` +
        "Aguarde enquanto a restauração é iniciada.\n" +
        "Isso pode levar alguns segundos."
    )
    .setColor(0xf1c40f)
    .setFooter({ text: "Restauração - Backup Bot" })
    .setTimestamp();

  await interaction.update({
    embeds: [loadingEmbed],
    components: [],
  });

  const targetGuildId = interaction.guild.id;
  const restoreId = await RestoreService.startRestore(
    backupId,
    targetGuildId,
    client
  );

  let targetGuildName = "Desconhecido";
  try {
    const targetGuild = await client.guilds.fetch(targetGuildId);
    targetGuildName = targetGuild.name;
  } catch {
    targetGuildName = "Servidor atual";
  }

  const embed = new EmbedBuilder()
    .setTitle("🔄 Restauração Iniciada")
    .setDescription(
      "A restauração do backup foi iniciada com sucesso!\n" +
        "Acompanhe o progresso usando o botão abaixo."
    )
    .addFields(
      {
        name: "📋 ID da Restauração",
        value: `\`${restoreId}\``,
        inline: true,
      },
      {
        name: "💾 Backup",
        value: `${backup.name}\n\`${backupId}\``,
        inline: true,
      },
      {
        name: "🏠 Servidor Alvo",
        value: `${targetGuildName}\n\`${targetGuildId}\``,
        inline: true,
      }
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Restauração - Backup Bot" })
    .setTimestamp();

  const statusButton = new ButtonBuilder()
    .setCustomId(`restore_status_${restoreId}`)
    .setLabel("Ver Status")
    .setStyle(ButtonStyle.Primary)
    .setEmoji("📊");

  const row = new ActionRowBuilder().addComponents(statusButton);

  client.restoreQueue.delete(interaction.user.id);

  await interaction.editReply({
    embeds: [embed],
    components: [row],
  });
}
