import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  MessageFlags,
} from "discord.js";
import BackupService from "../../../services/BackupService.js";

export async function handleBackupListAction(interaction, client) {
  const backupId = interaction.values[0];
  const backup = await BackupService.getBackup(backupId);

  if (backup.guildId !== interaction.guild.id) {
    return await interaction.reply({
      content: "❌ Este backup não pertence a este servidor.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
  const date = new Date(backup.createdAt);
  const dateStr = date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const embed = new EmbedBuilder()
    .setTitle(`📦 ${backup.name}`)
    .setDescription(
      `**ID:** \`${backup._id}\`\n` +
        `**Tamanho:** ${sizeMB} MB\n` +
        `**Tipo:** ${backup.isAutoBackup ? "🤖 Automático" : "💾 Manual"}\n` +
        `**Criado em:** ${dateStr}`
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  const infoButton = new ButtonBuilder()
    .setCustomId(`backup_info_${backup._id}`)
    .setLabel("Ver Informações")
    .setStyle(ButtonStyle.Primary)
    .setEmoji("ℹ️");

  const restoreButton = new ButtonBuilder()
    .setCustomId(`backup_restore_${backup._id}`)
    .setLabel("Restaurar")
    .setStyle(ButtonStyle.Success)
    .setEmoji("🔄");

  const deleteButton = new ButtonBuilder()
    .setCustomId(`backup_delete_${backup._id}`)
    .setLabel("Deletar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("🗑️");

  const row = new ActionRowBuilder().addComponents(
    infoButton,
    restoreButton,
    deleteButton
  );

  await interaction.update({
    embeds: [embed],
    components: [row],
  });
}

export async function handleBackupListBack(interaction) {
  const guildId = interaction.guild.id;
  const { backups, total } = await BackupService.listBackups(guildId, 25);

  if (backups.length === 0) {
    return await interaction.update({
      content:
        "📭 Nenhum backup encontrado para este servidor.\n\nUse `/backup criar` para criar um backup primeiro.",
      embeds: [],
      components: [],
    });
  }

  const options = backups.map((backup) => {
    const date = new Date(backup.createdAt);
    const dateStr = date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
    const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
    const typeEmoji = backup.isAutoBackup ? "🤖" : "💾";

    return new StringSelectMenuOptionBuilder()
      .setLabel(`${typeEmoji} ${backup.name}`)
      .setDescription(`${dateStr} • ${sizeMB} MB`)
      .setValue(backup._id.toString());
  });

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("backup_list_action")
    .setPlaceholder("Selecione um backup para ver ações disponíveis")
    .addOptions(options);

  const row = new ActionRowBuilder().addComponents(selectMenu);

  const embed = new EmbedBuilder()
    .setTitle("📦 Backups do Servidor")
    .setDescription(
      `**Total:** ${total} backup(s)\n\n` +
        `Selecione um backup abaixo para ver informações ou executar ações.\n\n` +
        `**Últimos backups:**`
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  for (let i = 0; i < Math.min(backups.length, 5); i++) {
    const backup = backups[i];
    const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
    const date = new Date(backup.createdAt);
    const dateStr = date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
    });
    const typeEmoji = backup.isAutoBackup ? "🤖" : "💾";

    embed.addFields({
      name: `${typeEmoji} ${backup.name}`,
      value: `ID: \`${backup._id}\` • ${sizeMB} MB • ${dateStr}`,
      inline: true,
    });
  }

  await interaction.update({
    embeds: [embed],
    components: [row],
  });
}
