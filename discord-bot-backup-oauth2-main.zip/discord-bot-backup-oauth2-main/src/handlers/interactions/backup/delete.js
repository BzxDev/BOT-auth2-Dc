import {
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ActionRowBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} from "discord.js";
import BackupService from "../../../services/BackupService.js";
import AuditLog from "../../../database/models/AuditLog.js";

async function renderBackupList(guildId) {
  const { backups, total } = await BackupService.listBackups(guildId, 25);

  if (backups.length === 0) {
    return {
      content:
        "📭 Nenhum backup encontrado para este servidor.\n\nUse `/backup criar` para criar um backup primeiro.",
      embeds: [],
      components: [],
    };
  }

  const options = backups.map((backup) => {
    const date = new Date(backup.createdAt);
    const dateStr = date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
    const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
    const typeEmoji = backup.isAutoBackup ? "🤖" : "💾";

    return new StringSelectMenuOptionBuilder()
      .setLabel(`${typeEmoji} ${backup.name}`)
      .setDescription(`${dateStr} • ${sizeMB} MB`)
      .setValue(backup._id.toString());
  });

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("backup_list_action")
    .setPlaceholder("Selecione um backup para ver ações disponíveis")
    .addOptions(options);

  const row = new ActionRowBuilder().addComponents(selectMenu);

  const embed = new EmbedBuilder()
    .setTitle("📦 Backups do Servidor")
    .setDescription(
      `**Total:** ${total} backup(s)\n\n` +
        `Selecione um backup abaixo para ver informações ou executar ações.\n\n` +
        `**Últimos backups:**`
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  for (let i = 0; i < Math.min(backups.length, 5); i++) {
    const backup = backups[i];
    const sizeMB = (backup.size / 1024 / 1024).toFixed(2);
    const date = new Date(backup.createdAt);
    const dateStr = date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
    });
    const typeEmoji = backup.isAutoBackup ? "🤖" : "💾";

    embed.addFields({
      name: `${typeEmoji} ${backup.name}`,
      value: `ID: \`${backup._id}\` • ${sizeMB} MB • ${dateStr}`,
      inline: true,
    });
  }

  return {
    content: "",
    embeds: [embed],
    components: [row],
  };
}

export async function handleDeleteConfirm(interaction, backupId) {
  await BackupService.deleteBackup(backupId);

  await AuditLog.create({
    action: "backup_deleted",
    userId: interaction.user.id,
    guildId: interaction.guild.id,
    details: { backupId },
  });

  const guildId = interaction.guild.id;
  const listData = await renderBackupList(guildId);

  if (!listData.components || listData.components.length === 0) {
    await interaction.update({
      content:
        "✅ Backup deletado com sucesso!\n\n📭 Não há mais backups disponíveis neste servidor.",
      components: [],
      embeds: [],
    });
    return;
  }

  await interaction.update(listData);
}

export async function handleDeleteCancel(interaction) {
  await interaction.update({
    content: "❌ Exclusão cancelada.",
    components: [],
    embeds: [],
  });
}

export async function handleBackupDeleteButton(interaction, backupId) {
  const backup = await BackupService.getBackup(backupId);

  if (backup.guildId !== interaction.guild.id) {
    return await interaction.reply({
      content: "❌ Este backup não pertence a este servidor.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const confirmButton = new ButtonBuilder()
    .setCustomId(`delete_confirm_${backupId}`)
    .setLabel("Confirmar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("✅");

  const cancelButton = new ButtonBuilder()
    .setCustomId(`delete_cancel_${backupId}`)
    .setLabel("Cancelar")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("❌");

  const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

  const embed = new EmbedBuilder()
    .setTitle("⚠️ Confirmar Exclusão")
    .setDescription(
      `Tem certeza que deseja deletar o backup **${backup.name}**?\n\n` +
        `**ID:** \`${backupId}\`\n\n` +
        `⚠️ **Esta ação não pode ser desfeita!**`
    )
    .setColor(0xf04747)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  await interaction.reply({
    embeds: [embed],
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleBackupDeleteSelect(interaction) {
  const backupId = interaction.values[0];
  const backup = await BackupService.getBackup(backupId);

  if (backup.guildId !== interaction.guild.id) {
    return await interaction.reply({
      content: "❌ Este backup não pertence a este servidor.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const confirmButton = new ButtonBuilder()
    .setCustomId(`delete_confirm_${backupId}`)
    .setLabel("Confirmar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("✅");

  const cancelButton = new ButtonBuilder()
    .setCustomId(`delete_cancel_${backupId}`)
    .setLabel("Cancelar")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("❌");

  const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

  const embed = new EmbedBuilder()
    .setTitle("⚠️ Confirmar Exclusão")
    .setDescription(
      `Tem certeza que deseja deletar o backup **${backup.name}**?\n\n` +
        `**ID:** \`${backupId}\`\n\n` +
        `⚠️ **Esta ação não pode ser desfeita!**`
    )
    .setColor(0xf04747)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  await interaction.update({
    embeds: [embed],
    components: [row],
  });
}
