import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import BackupService from "../../../services/BackupService.js";
import AuditLog from "../../../database/models/AuditLog.js";
import { COMPONENT_LABELS } from "../constants.js";

export async function handleBackupConfirm(interaction, client) {
  const queue = client.backupQueue?.get(interaction.user.id);
  if (!queue || !queue.components) {
    return await interaction.reply({
      content: "❌ Sessão expirada. Execute o comando novamente.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const componentList = Object.keys(queue.components)
    .map((key) => COMPONENT_LABELS[key] || key)
    .join("\n");

  const loadingEmbed = new EmbedBuilder()
    .setTitle("⏳ Criando Backup...")
    .setDescription(
      `**Nome:** ${queue.name}\n\n` +
        `**Componentes:**\n${componentList}\n\n` +
        `Por favor, aguarde enquanto o backup está sendo criado...`
    )
    .setColor(0xf1c40f)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  await interaction.update({
    embeds: [loadingEmbed],
    components: [],
  });

  const guild = await client.guilds.fetch(queue.guildId);
  const backup = await BackupService.createBackup(
    queue.guildId,
    queue.name,
    queue.components,
    guild,
    queue.userId
  );

  await AuditLog.create({
    action: "backup_created",
    userId: queue.userId,
    guildId: queue.guildId,
    details: { backupId: backup._id, backupName: queue.name },
  });

  client.backupQueue.delete(interaction.user.id);

  const successEmbed = new EmbedBuilder()
    .setTitle("✅ Backup Criado com Sucesso!")
    .setDescription(
      `**Nome:** ${queue.name}\n` +
        `**ID:** \`${backup._id}\`\n\n` +
        `**Componentes:**\n${componentList}`
    )
    .setColor(0x43b581)
    .setFooter({ text: "Backup - Backup Bot" })
    .setTimestamp();

  const infoButton = new ButtonBuilder()
    .setCustomId(`backup_info_${backup._id}`)
    .setLabel("Ver Informações")
    .setStyle(ButtonStyle.Primary)
    .setEmoji("ℹ️");

  const restoreButton = new ButtonBuilder()
    .setCustomId(`backup_restore_${backup._id}`)
    .setLabel("Restaurar")
    .setStyle(ButtonStyle.Success)
    .setEmoji("🔄");

  const deleteButton = new ButtonBuilder()
    .setCustomId(`backup_delete_${backup._id}`)
    .setLabel("Deletar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("🗑️");

  const row = new ActionRowBuilder().addComponents(
    infoButton,
    restoreButton,
    deleteButton
  );

  await interaction.editReply({
    embeds: [successEmbed],
    components: [row],
  });
}
