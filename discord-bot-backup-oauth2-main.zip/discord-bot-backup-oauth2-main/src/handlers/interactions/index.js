import logger from "../../utils/logger.js";
import {
  handleBackupComponents,
  handleBackupConfirm,
  handleBackupCancel,
  handleDeleteConfirm,
  handleDeleteCancel,
  handleBackupInfo,
  handleBackupInfoSelect,
  handleBackupRestore,
  handleBackupListAction,
  handleBackupListBack,
  handleBackupDeleteButton,
  handleBackupDeleteSelect,
} from "./backup/index.js";
import {
  handleRestoreBackupSelect,
  handleRestoreStatus,
} from "./restore/index.js";
import {
  handleSetupOAuth2Channel,
  handleSetupModeAutomatic,
  handleSetupModeManual,
} from "./setup/index.js";
import {
  handleAutobackupInterval,
  handleAutobackupComponents,
  handleAutobackupConfirm,
  handleAutobackupCancel,
  handleAutobackupDisable,
} from "./autobackup/index.js";

export async function handleComponentInteraction(interaction, client) {
  if (!interaction.isButton() && !interaction.isAnySelectMenu()) {
    return;
  }

  try {
    const customId = interaction.customId;

    if (interaction.isAnySelectMenu()) {
      const selectHandlers = {
        backup_components: () => handleBackupComponents(interaction, client),
        autobackup_interval: () =>
          handleAutobackupInterval(interaction, client),
        autobackup_components: () =>
          handleAutobackupComponents(interaction, client),
        setup_oauth2_channel: () => handleSetupOAuth2Channel(interaction),
        restore_backup_select: () =>
          handleRestoreBackupSelect(interaction, client),
        backup_list_action: () => handleBackupListAction(interaction, client),
        backup_info_select: () => handleBackupInfoSelect(interaction),
        backup_delete_select: () => handleBackupDeleteSelect(interaction),
      };

      const handler = selectHandlers[customId];
      if (handler) {
        return await handler();
      }
    }

    if (interaction.isButton()) {
      if (customId.startsWith("delete_confirm_")) {
        const backupId = customId.replace("delete_confirm_", "");
        return await handleDeleteConfirm(interaction, backupId);
      }

      if (customId.startsWith("delete_cancel_")) {
        return await handleDeleteCancel(interaction);
      }

      if (customId.startsWith("backup_info_")) {
        const backupId = customId.replace("backup_info_", "");
        return await handleBackupInfo(interaction, backupId);
      }

      if (customId.startsWith("backup_restore_")) {
        const backupId = customId.replace("backup_restore_", "");
        return await handleBackupRestore(interaction, backupId, client);
      }

      if (customId.startsWith("backup_delete_")) {
        const backupId = customId.replace("backup_delete_", "");
        return await handleBackupDeleteButton(interaction, backupId);
      }

      if (customId.startsWith("restore_status_")) {
        const restoreId = customId.replace("restore_status_", "");
        return await handleRestoreStatus(interaction, restoreId);
      }

      const buttonHandlers = {
        backup_confirm: () => handleBackupConfirm(interaction, client),
        backup_cancel: () => handleBackupCancel(interaction, client),
        autobackup_confirm: () => handleAutobackupConfirm(interaction, client),
        autobackup_cancel: () => handleAutobackupCancel(interaction, client),
        autobackup_disable: () => handleAutobackupDisable(interaction),
        backup_list_back: () => handleBackupListBack(interaction),
        setup_mode_automatic: () => handleSetupModeAutomatic(interaction),
        setup_mode_manual: () => handleSetupModeManual(interaction),
      };

      const handler = buttonHandlers[customId];
      if (handler) {
        return await handler();
      }
    }

    logger.warn(`Unhandled interaction: ${customId}`);
  } catch (error) {
    logger.error("Component interaction error:", error);
    const reply =
      interaction.replied || interaction.deferred
        ? interaction.followUp.bind(interaction)
        : interaction.reply.bind(interaction);

    await reply({
      content: `❌ Erro: ${error.message}`,
      flags: require("discord.js").MessageFlags.Ephemeral,
    }).catch(() => {});
  }
}

export * from "./constants.js";
