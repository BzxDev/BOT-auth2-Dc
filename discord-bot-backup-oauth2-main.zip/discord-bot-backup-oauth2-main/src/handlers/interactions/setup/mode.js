import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ChannelSelectMenuBuilder,
} from "discord.js";
import GuildConfig from "../../../database/models/GuildConfig.js";

export async function handleSetupModeAutomatic(interaction) {
  const guildId = interaction.guild.id;
  const userId = interaction.user.id;

  await GuildConfig.findOneAndUpdate(
    { guildId },
    {
      guildId,
      channelRestoreMode: "automatic",
      updatedBy: userId,
      updatedAt: new Date(),
    },
    { upsert: true, new: true }
  );

  const embed = new EmbedBuilder()
    .setTitle("✅ Modo Alterado para Automático")
    .setDescription(
      `**Tipo de Restauração:** 🤖 Automático - Criar todos os canais\n\n` +
        `A configuração foi atualizada com sucesso. Esta configuração será aplicada em todas as restaurações futuras deste servidor.\n\n` +
        `O bot criará automaticamente todos os canais durante a restauração.`
    )
    .setColor(0x43b581)
    .setFooter({ text: "Configuração de Restauração - Backup Bot" })
    .setTimestamp();

  const automaticButton = new ButtonBuilder()
    .setCustomId("setup_mode_automatic")
    .setLabel("Automático")
    .setStyle(ButtonStyle.Success)
    .setEmoji("🤖")
    .setDisabled(true);

  const manualButton = new ButtonBuilder()
    .setCustomId("setup_mode_manual")
    .setLabel("Manual")
    .setStyle(ButtonStyle.Primary)
    .setEmoji("✋")
    .setDisabled(false);

  const row = new ActionRowBuilder().addComponents(
    automaticButton,
    manualButton
  );

  await interaction.update({
    embeds: [embed],
    components: [row],
  });
}

export async function handleSetupModeManual(interaction) {
  const guildId = interaction.guild.id;
  const userId = interaction.user.id;

  await GuildConfig.findOneAndUpdate(
    { guildId },
    {
      guildId,
      channelRestoreMode: "manual",
      updatedBy: userId,
      updatedAt: new Date(),
    },
    { upsert: true, new: true }
  );

  const embed = new EmbedBuilder()
    .setTitle("✅ Modo Alterado para Manual")
    .setDescription(
      `**Tipo de Restauração:** ✋ Manual - Apenas configurar canais existentes\n\n` +
        `Para coletar tokens OAuth2 dos membros e permitir restauração após raids/mass bans, selecione o canal onde deseja enviar a embed de autorização OAuth2.\n\n` +
        `**Como funciona:**\n` +
        `1. Selecione um canal abaixo\n` +
        `2. Uma embed será enviada no canal escolhido\n` +
        `3. Membros clicam no botão para autorizar\n` +
        `4. Tokens são armazenados com segurança (criptografados)\n` +
        `5. Em caso de raid/mass ban, o bot pode restaurar os membros`
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Configuração Manual - Backup Bot" })
    .setTimestamp();

  const automaticButton = new ButtonBuilder()
    .setCustomId("setup_mode_automatic")
    .setLabel("Automático")
    .setStyle(ButtonStyle.Primary)
    .setEmoji("🤖")
    .setDisabled(false);

  const manualButton = new ButtonBuilder()
    .setCustomId("setup_mode_manual")
    .setLabel("Manual")
    .setStyle(ButtonStyle.Success)
    .setEmoji("✋")
    .setDisabled(true);

  const channelSelect = new ChannelSelectMenuBuilder()
    .setCustomId("setup_oauth2_channel")
    .setPlaceholder("Selecione o canal para enviar a embed OAuth2")
    .setMinValues(1)
    .setMaxValues(1);

  const row1 = new ActionRowBuilder().addComponents(
    automaticButton,
    manualButton
  );
  const row2 = new ActionRowBuilder().addComponents(channelSelect);

  await interaction.update({
    embeds: [embed],
    components: [row1, row2],
  });
}
