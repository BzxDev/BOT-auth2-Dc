import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import OAuth2Service from "../../../services/OAuth2Service.js";

export async function handleSetupOAuth2Channel(interaction) {
  if (interaction.isStringSelectMenu()) {
    return await interaction.reply({
      content: "❌ Tipo de interação inválido. Selecione um canal.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const selectedChannelId = interaction.values[0];
  const channel = await interaction.guild.channels.fetch(selectedChannelId);

  if (!channel || !channel.isTextBased()) {
    return await interaction.reply({
      content: "❌ Canal inválido ou não é um canal de texto.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const guildId = interaction.guild.id;
  const state = `${guildId}-${Date.now()}`;
  const authUrl = OAuth2Service.generateAuthUrl(state, guildId);

  const oauth2Embed = new EmbedBuilder()
    .setTitle("Autorização OAuth2")
    .setDescription(
      "Para restaurar membros após um incidente de segurança (raid ou mass ban), você precisa autorizar o bot a usar tokens OAuth2.\n\n" +
        "**Como funciona:**\n" +
        "1. Clique no botão abaixo\n" +
        "2. Autorize o bot no Discord\n" +
        "3. Seu token será armazenado com segurança (criptografado)\n" +
        "4. O bot poderá restaurar você em servidores após raids/mass bans\n\n" +
        "⚠️ **Importante:** Seus tokens são criptografados e armazenados de forma segura. Esta autorização permite que o bot restaure você no servidor caso você seja removido."
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Autorização OAuth2 - Backup Bot" })
    .setTimestamp();

  const button = new ButtonBuilder()
    .setLabel("Autorizar")
    .setStyle(ButtonStyle.Link)
    .setURL(authUrl);

  const row = new ActionRowBuilder().addComponents(button);

  await channel.send({
    embeds: [oauth2Embed],
    components: [row],
  });

  const confirmEmbed = new EmbedBuilder()
    .setTitle("✅ Embed OAuth2 Enviada")
    .setDescription(
      `A embed de autorização OAuth2 foi enviada com sucesso no canal ${channel}.\n\n` +
        `Os membros podem agora clicar no botão "Autorizar" para permitir que o bot restaure eles em caso de raid ou mass ban.`
    )
    .setColor(0x43b581)
    .setFooter({ text: "Configuração Manual - Backup Bot" })
    .setTimestamp();

  await interaction.update({
    embeds: [confirmEmbed],
    components: [],
  });
}
