import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import RestoreService from "../../../services/RestoreService.js";
import BackupService from "../../../services/BackupService.js";

export async function handleRestoreBackupSelect(interaction, client) {
  const queue = client.restoreQueue?.get(interaction.user.id);
  if (!queue) {
    return await interaction.reply({
      content: "❌ Sessão expirada. Execute o comando novamente.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const backupId = interaction.values[0];
  const targetGuildId = queue.guildId;

  const loadingEmbed = new EmbedBuilder()
    .setTitle("⏳ Iniciando Restauração...")
    .setDescription(
      "Aguarde enquanto a restauração é iniciada.\n" +
        "Isso pode levar alguns segundos."
    )
    .setColor(0xf1c40f)
    .setFooter({ text: "Restauração - Backup Bot" })
    .setTimestamp();

  await interaction.update({
    embeds: [loadingEmbed],
    components: [],
  });

  const restoreId = await RestoreService.startRestore(
    backupId,
    targetGuildId,
    client
  );

  const backup = await BackupService.getBackup(backupId);

  let targetGuildName = "Desconhecido";
  try {
    const targetGuild = await client.guilds.fetch(targetGuildId);
    targetGuildName = targetGuild.name;
  } catch {
    targetGuildName = "Servidor atual";
  }

  const embed = new EmbedBuilder()
    .setTitle("🔄 Restauração Iniciada")
    .setDescription(
      "A restauração do backup foi iniciada com sucesso!\n" +
        "Acompanhe o progresso usando o botão abaixo."
    )
    .addFields(
      {
        name: "📋 ID da Restauração",
        value: `\`${restoreId}\``,
        inline: true,
      },
      {
        name: "💾 Backup",
        value: `${backup.name}\n\`${backupId}\``,
        inline: true,
      },
      {
        name: "🏠 Servidor Alvo",
        value: `${targetGuildName}\n\`${targetGuildId}\``,
        inline: true,
      }
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Restauração - Backup Bot" })
    .setTimestamp();

  const statusButton = new ButtonBuilder()
    .setCustomId(`restore_status_${restoreId}`)
    .setLabel("Ver Status")
    .setStyle(ButtonStyle.Primary)
    .setEmoji("📊");

  const row = new ActionRowBuilder().addComponents(statusButton);

  client.restoreQueue.delete(interaction.user.id);

  await interaction.editReply({
    embeds: [embed],
    components: [row],
  });
}
