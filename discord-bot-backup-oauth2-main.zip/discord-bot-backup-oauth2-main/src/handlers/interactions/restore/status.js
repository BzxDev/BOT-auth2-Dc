import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import RestoreService from "../../../services/RestoreService.js";

function createProgressBar(progress) {
  const filled = Math.round(progress / 10);
  const empty = 10 - filled;
  return `\`[${"█".repeat(filled)}${"░".repeat(empty)}]\` ${progress}%`;
}

export async function handleRestoreStatus(interaction, restoreId) {
  const status = RestoreService.getRestoreStatus(restoreId);

  if (!status) {
    return await interaction.reply({
      content: "❌ Restauração não encontrada ou já foi concluída.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const progressBar = createProgressBar(status.progress);
  const statusEmoji =
    {
      in_progress: "🔄",
      completed: "✅",
      failed: "❌",
    }[status.status] || "⏳";

  const statusText =
    {
      in_progress: "Em Andamento",
      completed: "Concluída",
      failed: "Falhou",
    }[status.status] || status.status;

  const statusColor =
    {
      in_progress: 0x5865f2,
      completed: 0x43b581,
      failed: 0xf04747,
    }[status.status] || 0x99aab5;

  const embed = new EmbedBuilder()
    .setTitle(`${statusEmoji} Status da Restauração`)
    .addFields(
      { name: "📋 ID", value: `\`${restoreId}\``, inline: true },
      { name: "📊 Status", value: statusText, inline: true },
      { name: "📈 Progresso", value: `${status.progress}%`, inline: true },
      { name: "Barra de Progresso", value: progressBar, inline: false }
    )
    .setColor(statusColor)
    .setFooter({ text: "Restauração - Backup Bot" })
    .setTimestamp();

  if (status.steps && status.steps.length > 0) {
    const recentSteps = status.steps.slice(-5);
    embed.addFields({
      name: "📝 Últimas Etapas",
      value: recentSteps.map((step, i) => `${i + 1}. ${step}`).join("\n"),
      inline: false,
    });
  }

  if (status.error) {
    embed.addFields({
      name: "❌ Erro",
      value: `\`\`\`${status.error}\`\`\``,
      inline: false,
    });
  }

  const refreshButton = new ButtonBuilder()
    .setCustomId(`restore_status_${restoreId}`)
    .setLabel("Atualizar")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("🔄");

  const row = new ActionRowBuilder().addComponents(refreshButton);

  if (interaction.replied || interaction.deferred) {
    await interaction.editReply({
      embeds: [embed],
      components: [row],
    });
  } else {
    await interaction.reply({
      embeds: [embed],
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  }
}
