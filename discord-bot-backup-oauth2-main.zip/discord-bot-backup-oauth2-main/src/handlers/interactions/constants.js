export const ALL_COMPONENTS = [
  "serverSettings",
  "channels",
  "roles",
  "members",
  "emojis",
  "stickers",
  "permissions",
];

export const COMPONENT_LABELS = {
  serverSettings: "⚙️ Configurações do Servidor",
  channels: "📁 Canais",
  roles: "👑 Cargos",
  members: "👥 Membros",
  emojis: "😀 Emojis",
  stickers: "🎨 Stickers",
  permissions: "🔐 Permissões",
};

export const INTERVAL_LABELS = {
  "1week": "1 Semana",
  "2weeks": "2 Semanas",
  "3weeks": "3 Semanas",
  "1month": "1 Mês",
};

export const ADMIN_CATEGORIES = ["backup", "restore", "setup"];

export function processSelectedComponents(selectedValues) {
  let values = selectedValues;

  if (values.includes("all")) {
    values = ALL_COMPONENTS;
  }

  const components = {};
  for (const value of values) {
    if (value !== "all") {
      components[value] = true;
    }
  }

  return components;
}

export function formatComponentList(components) {
  return Object.keys(components)
    .map((key) => COMPONENT_LABELS[key] || key)
    .join("\n");
}
