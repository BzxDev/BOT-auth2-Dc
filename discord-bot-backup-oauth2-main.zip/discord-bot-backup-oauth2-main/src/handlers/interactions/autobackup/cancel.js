export async function handleAutobackupCancel(interaction, client) {
  client.autobackupQueue?.delete(interaction.user.id);

  await interaction.update({
    content: "❌ Configuração de backup automático cancelada.",
    embeds: [],
    components: [],
  });
}
