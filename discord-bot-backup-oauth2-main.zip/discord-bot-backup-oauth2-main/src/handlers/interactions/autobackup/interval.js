import {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} from "discord.js";
import { INTERVAL_LABELS } from "../constants.js";

export async function handleAutobackupInterval(interaction, client) {
  const interval = interaction.values[0];

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("autobackup_components")
    .setPlaceholder("Selecione os componentes para backup automático")
    .setMinValues(1)
    .setMaxValues(8)
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel("Tudo")
        .setDescription("Selecionar todos os componentes")
        .setValue("all")
        .setEmoji("✅"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Configurações do Servidor")
        .setDescription("Nome, ícone, descrição, etc.")
        .setValue("serverSettings")
        .setEmoji("⚙️"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Canais")
        .setDescription("Todos os canais e categorias")
        .setValue("channels")
        .setEmoji("📁"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Cargos")
        .setDescription("Todos os cargos e permissões")
        .setValue("roles")
        .setEmoji("👑"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Membros")
        .setDescription("Lista de membros e seus cargos")
        .setValue("members")
        .setEmoji("👥"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Emojis")
        .setDescription("Todos os emojis personalizados")
        .setValue("emojis")
        .setEmoji("😀"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Stickers")
        .setDescription("Todos os stickers personalizados")
        .setValue("stickers")
        .setEmoji("🎨"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Permissões")
        .setDescription("Permissões de canais e cargos")
        .setValue("permissions")
        .setEmoji("🔐")
    );

  const row = new ActionRowBuilder().addComponents(selectMenu);

  await interaction.update({
    content: `🤖 **Backup Automático - Intervalo: ${INTERVAL_LABELS[interval] || interval}**\n\nSelecione os componentes que deseja incluir no backup:`,
    components: [row],
  });

  client.autobackupQueue = client.autobackupQueue || new Map();
  client.autobackupQueue.set(interaction.user.id, {
    interval,
    intervalLabel: INTERVAL_LABELS[interval] || interval,
    guildId: interaction.guild.id,
  });
}
