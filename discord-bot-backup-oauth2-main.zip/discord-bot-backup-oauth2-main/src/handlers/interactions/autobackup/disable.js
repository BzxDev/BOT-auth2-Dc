import { EmbedBuilder } from "discord.js";
import SchedulerService from "../../../services/SchedulerService.js";

export async function handleAutobackupDisable(interaction) {
  await interaction.deferUpdate();

  await SchedulerService.cancelAutoBackup(interaction.guild.id);

  const embed = new EmbedBuilder()
    .setTitle("🛑 Backup Automático Desativado")
    .setDescription(
      "O backup automático foi desativado com sucesso.\n\n" +
        "Use `/backup autobackup` para configurar novamente."
    )
    .setColor(0xf04747)
    .setFooter({ text: "Backup Automático - Backup Bot" })
    .setTimestamp();

  await interaction.editReply({
    embeds: [embed],
    components: [],
  });
}
