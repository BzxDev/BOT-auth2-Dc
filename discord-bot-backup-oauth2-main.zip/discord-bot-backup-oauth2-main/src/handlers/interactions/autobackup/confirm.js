import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import SchedulerService from "../../../services/SchedulerService.js";
import { COMPONENT_LABELS } from "../constants.js";

export async function handleAutobackupConfirm(interaction, client) {
  const queue = client.autobackupQueue?.get(interaction.user.id);
  if (!queue || !queue.components) {
    return await interaction.reply({
      content: "❌ Sessão expirada. Execute o comando novamente.",
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.deferUpdate();

  await SchedulerService.scheduleAutoBackup(
    queue.guildId,
    queue.interval,
    queue.components,
    interaction.user.id,
    client
  );

  client.autobackupQueue.delete(interaction.user.id);

  const componentList = Object.keys(queue.components)
    .map((key) => COMPONENT_LABELS[key] || key)
    .join("\n");

  const embed = new EmbedBuilder()
    .setTitle("✅ Backup Automático Configurado!")
    .setDescription(
      `**Intervalo:** ${queue.intervalLabel}\n\n` +
        `**Componentes:**\n${componentList}\n\n` +
        `Use o botão abaixo para desativar o backup automático.`
    )
    .setColor(0x43b581)
    .setFooter({ text: "Backup Automático - Backup Bot" })
    .setTimestamp();

  const disableButton = new ButtonBuilder()
    .setCustomId("autobackup_disable")
    .setLabel("Desativar Backup Automático")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("🛑");

  const row = new ActionRowBuilder().addComponents(disableButton);

  await interaction.editReply({
    content: "",
    embeds: [embed],
    components: [row],
  });
}
