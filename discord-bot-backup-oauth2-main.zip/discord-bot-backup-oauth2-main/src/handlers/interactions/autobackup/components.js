import {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  MessageFlags,
} from "discord.js";
import {
  processSelectedComponents,
  formatComponentList,
} from "../constants.js";

export async function handleAutobackupComponents(interaction, client) {
  const queue = client.autobackupQueue.get(interaction.user.id);
  if (!queue) {
    return await interaction.reply({
      content: "❌ Sessão expirada. Execute o comando novamente.",
      flags: MessageFlags.Ephemeral,
    });
  }

  const selectedComponents = processSelectedComponents(interaction.values);
  queue.components = selectedComponents;
  client.autobackupQueue.set(interaction.user.id, queue);

  const componentList = formatComponentList(selectedComponents);

  const embed = new EmbedBuilder()
    .setTitle("🤖 Confirmar Backup Automático")
    .setDescription(
      `**Intervalo:** ${queue.intervalLabel}\n\n` +
        `**Componentes selecionados:**\n${componentList}\n\n` +
        `Clique em **Confirmar** para ativar o backup automático.`
    )
    .setColor(0x5865f2)
    .setFooter({ text: "Backup Automático - Backup Bot" })
    .setTimestamp();

  const confirmButton = new ButtonBuilder()
    .setCustomId("autobackup_confirm")
    .setLabel("Confirmar")
    .setStyle(ButtonStyle.Success)
    .setEmoji("✅");

  const cancelButton = new ButtonBuilder()
    .setCustomId("autobackup_cancel")
    .setLabel("Cancelar")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("❌");

  const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

  await interaction.update({
    content: "",
    embeds: [embed],
    components: [row],
  });
}
