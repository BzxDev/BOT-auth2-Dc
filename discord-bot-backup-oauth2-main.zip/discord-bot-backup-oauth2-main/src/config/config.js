import dotenv from "dotenv";

dotenv.config();

const requiredEnvVars = [
  "BOT_TOKEN",
  "CLIENT_ID",
  "CLIENT_SECRET",
  "REDIRECT_URI",
  "DATABASE",
  "PORT",
];

// Validate required environment variables
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    throw new Error(`Missing required environment variable: ${envVar}`);
  }
}

const config = {
  bot: {
    token: process.env.BOT_TOKEN,
    clientId: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    redirectUri: process.env.REDIRECT_URI,
  },
  database: {
    uri: process.env.DATABASE,
  },
  server: {
    port: parseInt(process.env.PORT, 10) || 80,
  },
  encryption: {
    key: process.env.ENCRYPTION_KEY || null, // Optional - uses CLIENT_SECRET if not provided
  },
  admin: {
    ids: process.env.ADMIN_IDS
      ? process.env.ADMIN_IDS.split(",").map((id) => id.trim())
      : [],
  },
  log: {
    level: process.env.LOG_LEVEL || "info",
  },
};

export default config;
