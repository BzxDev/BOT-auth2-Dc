import express from "express";
import OAuth2Service from "../../services/OAuth2Service.js";
import EncryptionService from "../../services/EncryptionService.js";
import OAuthToken from "../../database/models/OAuthToken.js";
import logger from "../../utils/logger.js";

const router = express.Router();

export default (client) => {
  // OAuth2 callback route
  router.get("/callback", async (req, res) => {
    try {
      const { code } = req.query;

      if (!code) {
        return res.send(
          renderCallbackPage(false, "Código de autorização não fornecido")
        );
      }

      // Exchange code for token
      const tokenData = await OAuth2Service.exchangeCodeForToken(code);

      // Get user info from Discord
      const userResponse = await fetch("https://discord.com/api/users/@me", {
        headers: {
          Authorization: `Bearer ${tokenData.access_token}`,
        },
      });
      const userData = await userResponse.json();

      // Encrypt tokens
      const encryptedToken = EncryptionService.encrypt(tokenData.access_token);
      const encryptedRefreshToken = EncryptionService.encrypt(
        tokenData.refresh_token
      );
      const expiresAt = new Date(Date.now() + tokenData.expires_in * 1000);

      // Save or update token
      await OAuthToken.findOneAndUpdate(
        { userId: userData.id },
        {
          userId: userData.id,
          encryptedToken,
          encryptedRefreshToken,
          expiresAt,
          scopes: tokenData.scope.split(" "),
          email: userData.email || null,
          createdAt: new Date(),
        },
        { upsert: true, new: true }
      );

      // Try to send DM confirmation
      try {
        const user = await client.users.fetch(userData.id);
        await user.send(
          "✅ Autorização OAuth2 concluída com sucesso! Seu token foi armazenado com segurança."
        );
      } catch (error) {
        logger.warn("Failed to send DM confirmation:", error.message);
      }

      logger.info(`OAuth2 token stored for user ${userData.id}`);

      res.send(
        renderCallbackPage(
          true,
          "Autorização concluída com sucesso! Você pode fechar esta página."
        )
      );
    } catch (error) {
      logger.error("OAuth2 callback error:", error);
      res.send(
        renderCallbackPage(
          false,
          `Erro ao processar autorização: ${error.message}`
        )
      );
    }
  });

  return router;
};

function renderCallbackPage(success, message) {
  const html = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Autorização OAuth2</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      background: #2f3136;
      color: #dcddde;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 20px;
    }
    .container {
      background: #36393f;
      border-radius: 8px;
      padding: 40px;
      text-align: center;
      max-width: 500px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    }
    .success {
      color: #43b581;
    }
    .error {
      color: #f04747;
    }
    h1 {
      margin-bottom: 20px;
      font-size: 24px;
    }
    p {
      margin-bottom: 20px;
      font-size: 16px;
      line-height: 1.5;
    }
    .icon {
      font-size: 48px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="icon">${success ? "✅" : "❌"}</div>
    <h1 class="${success ? "success" : "error"}">${success ? "Sucesso!" : "Erro"}</h1>
    <p>${message}</p>
    <p style="font-size: 14px; color: #72767d;">Esta página será fechada automaticamente em 3 segundos...</p>
  </div>
  <script>
    setTimeout(() => {
      window.close();
    }, 3000);
  </script>
</body>
</html>
  `;
  return html;
}
