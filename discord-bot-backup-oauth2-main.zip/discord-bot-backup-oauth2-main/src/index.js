import BotClient from "./structures/Client.js";
import config from "./config/config.js";
import logger from "./utils/logger.js";
import eventHandlers from "./handlers/event.js";

const client = new BotClient();

// Register event handlers
for (const [eventName, handler] of Object.entries(eventHandlers)) {
  client.on(eventName, (...args) => handler(...args, client));
}

// Handle process errors
process.on("unhandledRejection", (error) => {
  logger.error("Unhandled promise rejection:", error);
});

process.on("uncaughtException", (error) => {
  logger.error("Uncaught exception:", error);
  process.exit(1);
});

// Graceful shutdown
process.on("SIGINT", async () => {
  logger.info("Shutting down...");
  if (client.webServer) {
    await client.webServer.stop();
  }
  await client.destroy();
  process.exit(0);
});

// Login
client.login(config.bot.token).catch((error) => {
  logger.error("Failed to login:", error);
  process.exit(1);
});
