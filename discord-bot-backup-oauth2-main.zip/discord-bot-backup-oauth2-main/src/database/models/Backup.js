import mongoose from 'mongoose';

const BackupSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    index: true
  },
  name: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now,
    index: true
  },
  createdBy: {
    type: String,
    required: true
  },
  size: {
    type: Number,
    required: true
  },
  compressed: {
    type: Boolean,
    default: true
  },
  includedComponents: {
    serverSettings: { type: Boolean, default: false },
    channels: { type: Boolean, default: false },
    roles: { type: Boolean, default: false },
    members: { type: Boolean, default: false },
    messages: { type: Boolean, default: false },
    emojis: { type: Boolean, default: false },
    stickers: { type: Boolean, default: false },
    permissions: { type: Boolean, default: false }
  },
  data: {
    type: Buffer,
    required: true
  },
  metadata: {
    memberCount: { type: Number, default: 0 },
    channelCount: { type: Number, default: 0 },
    roleCount: { type: Number, default: 0 },
    messageCount: { type: Number, default: 0 }
  },
  isAutoBackup: {
    type: Boolean,
    default: false
  }
});

export default mongoose.model('Backup', BackupSchema);
