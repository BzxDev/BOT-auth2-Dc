import mongoose from 'mongoose';

const OAuthTokenSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  encryptedToken: {
    type: String,
    required: true
  },
  encryptedRefreshToken: {
    type: String,
    required: true
  },
  expiresAt: {
    type: Date,
    required: true
  },
  scopes: [{
    type: String
  }],
  email: {
    type: String,
    required: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('OAuthToken', OAuthTokenSchema);
