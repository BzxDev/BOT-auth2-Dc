import mongoose from 'mongoose';

const AutoBackupSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  enabled: {
    type: Boolean,
    default: true
  },
  interval: {
    type: String,
    required: true,
    enum: ['1week', '2weeks', '3weeks', '1month']
  },
  intervalHours: {
    type: Number,
    required: true
  },
  includedComponents: {
    serverSettings: { type: Boolean, default: false },
    channels: { type: Boolean, default: false },
    roles: { type: Boolean, default: false },
    members: { type: Boolean, default: false },
    messages: { type: Boolean, default: false },
    emojis: { type: Boolean, default: false },
    stickers: { type: Boolean, default: false },
    permissions: { type: Boolean, default: false }
  },
  lastBackup: {
    type: Date
  },
  nextBackup: {
    type: Date,
    required: true,
    index: true
  },
  createdBy: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('AutoBackup', AutoBackupSchema);
