import mongoose from "mongoose";

const GuildConfigSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  channelRestoreMode: {
    type: String,
    enum: ["automatic", "manual"],
    default: "automatic",
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  updatedBy: {
    type: String,
    required: true,
  },
});

export default mongoose.model("GuildConfig", GuildConfigSchema);
