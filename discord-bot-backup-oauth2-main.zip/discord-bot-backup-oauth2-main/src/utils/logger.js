const logLevels = {
  error: 0,
  warn: 1,
  info: 2,
  debug: 3
};

const currentLevel = logLevels[process.env.LOG_LEVEL || 'info'] || logLevels.info;

// Serializa erros corretamente, incluindo erros do Discord.js
const serializeArg = (arg) => {
  if (arg instanceof Error) {
    return {
      name: arg.name,
      message: arg.message,
      stack: arg.stack,
      ...(arg.code && { code: arg.code }),
      ...(arg.rawError && { rawError: arg.rawError }),
    };
  }
  if (arg && typeof arg === 'object' && arg.name && arg.message) {
    // Objetos tipo erro do Discord.js
    return {
      name: arg.name,
      message: arg.message,
      ...(arg.code && { code: arg.code }),
      ...(arg.data && { data: arg.data }),
    };
  }
  return arg;
};

const formatMessage = (level, message, ...args) => {
  const timestamp = new Date().toISOString();
  const serializedArgs = args.map(serializeArg);
  const formattedArgs = serializedArgs.length > 0 
    ? ' ' + JSON.stringify(serializedArgs, null, 0) 
    : '';
  return `[${timestamp}] [${level.toUpperCase()}] ${message}${formattedArgs}`;
};

const logger = {
  error: (message, ...args) => {
    if (currentLevel >= logLevels.error) {
      console.error(formatMessage('error', message, ...args));
    }
  },
  warn: (message, ...args) => {
    if (currentLevel >= logLevels.warn) {
      console.warn(formatMessage('warn', message, ...args));
    }
  },
  info: (message, ...args) => {
    if (currentLevel >= logLevels.info) {
      console.log(formatMessage('info', message, ...args));
    }
  },
  debug: (message, ...args) => {
    if (currentLevel >= logLevels.debug) {
      console.log(formatMessage('debug', message, ...args));
    }
  }
};

export default logger;
