export const validateBackupId = (backupId) => {
  if (!backupId || typeof backupId !== 'string') {
    throw new Error('ID do backup inválido');
  }
  return true;
};

export const validateGuildId = (guildId) => {
  if (!guildId || typeof guildId !== 'string') {
    throw new Error('ID do servidor inválido');
  }
  return true;
};

export const validateBackupName = (name) => {
  if (!name || typeof name !== 'string' || name.length < 1 || name.length > 100) {
    throw new Error('Nome do backup deve ter entre 1 e 100 caracteres');
  }
  return true;
};

export const validateInterval = (interval) => {
  const validIntervals = ['1week', '2weeks', '3weeks', '1month'];
  if (!validIntervals.includes(interval)) {
    throw new Error(`Intervalo inválido. Use: ${validIntervals.join(', ')}`);
  }
  return true;
};

export default {
  validateBackupId,
  validateGuildId,
  validateBackupName,
  validateInterval
};
