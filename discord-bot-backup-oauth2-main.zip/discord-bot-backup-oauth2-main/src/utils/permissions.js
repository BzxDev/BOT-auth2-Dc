import { PermissionFlagsBits } from "discord.js";
import config from "../config/config.js";

// Mapeamento de permissões para nomes legíveis em português
export const PERMISSION_NAMES = {
  Administrator: "Administrador",
  ManageGuild: "Gerenciar Servidor",
  ManageChannels: "Gerenciar Canais",
  ManageRoles: "Gerenciar Cargos",
  ManageMessages: "Gerenciar Mensagens",
  ManageNicknames: "Gerenciar Apelidos",
  ManageWebhooks: "Gerenciar Webhooks",
  ManageEmojisAndStickers: "Gerenciar Emojis e Stickers",
  KickMembers: "Expulsar Membros",
  BanMembers: "Banir Membros",
  ViewChannel: "Ver Canais",
  SendMessages: "Enviar Mensagens",
  EmbedLinks: "Inserir Links",
  AttachFiles: "Anexar Arquivos",
  ReadMessageHistory: "Ler Histórico de Mensagens",
  MentionEveryone: "Mencionar Everyone",
  UseExternalEmojis: "Usar Emojis Externos",
  ViewAuditLog: "Ver Registro de Auditoria",
  Connect: "Conectar",
  Speak: "Falar",
  MuteMembers: "Silenciar Membros",
  DeafenMembers: "Ensurdecer Membros",
  MoveMembers: "Mover Membros",
};

// Verifica se o usuário é admin (via ADMIN_IDS ou permissão Administrator)
export const isAdmin = (userId, member) => {
  if (config.admin.ids.includes(userId)) {
    return true;
  }

  if (member && member.permissions.has(PermissionFlagsBits.Administrator)) {
    return true;
  }

  return false;
};

// Verifica se o membro tem uma permissão específica
export const hasPermission = (member, permission) => {
  if (!member) return false;
  return member.permissions.has(permission);
};

// Lança erro se o usuário não for admin
export const requireAdmin = (interaction) => {
  const userId = interaction.user.id;
  const member = interaction.member;

  if (!isAdmin(userId, member)) {
    throw new Error(
      "Você não tem permissão para usar este comando. Apenas administradores podem usar este comando."
    );
  }
};

// Verifica permissões do bot e retorna as que estão faltando
export const checkBotPermissions = (interaction, permissions) => {
  if (!permissions || permissions.length === 0) {
    return { hasAll: true, missing: [] };
  }

  const botMember = interaction.guild?.members?.me;
  if (!botMember) {
    return { hasAll: false, missing: permissions };
  }

  const missing = [];
  for (const permission of permissions) {
    const permFlag = PermissionFlagsBits[permission];
    if (permFlag && !botMember.permissions.has(permFlag)) {
      missing.push(permission);
    }
  }

  return {
    hasAll: missing.length === 0,
    missing,
  };
};

// Verifica permissões do usuário e retorna as que estão faltando
export const checkUserPermissions = (interaction, permissions) => {
  if (!permissions || permissions.length === 0) {
    return { hasAll: true, missing: [] };
  }

  const member = interaction.member;
  if (!member) {
    return { hasAll: false, missing: permissions };
  }

  // Se o usuário for admin via ADMIN_IDS, tem todas as permissões
  if (config.admin.ids.includes(interaction.user.id)) {
    return { hasAll: true, missing: [] };
  }

  const missing = [];
  for (const permission of permissions) {
    const permFlag = PermissionFlagsBits[permission];
    if (permFlag && !member.permissions.has(permFlag)) {
      missing.push(permission);
    }
  }

  return {
    hasAll: missing.length === 0,
    missing,
  };
};

// Formata lista de permissões faltantes para exibição
export const formatMissingPermissions = (permissions) => {
  return permissions
    .map((perm) => `\`${PERMISSION_NAMES[perm] || perm}\``)
    .join(", ");
};

export default {
  isAdmin,
  hasPermission,
  requireAdmin,
  checkBotPermissions,
  checkUserPermissions,
  formatMissingPermissions,
  PERMISSION_NAMES,
};
