/**
 * Configurações e constantes para categorias de comandos
 */

// Constantes de categorias
export const COMMAND_CATEGORIES = {
  BACKUP: "backup",
  RESTORE: "restore",
  SETUP: "setup",
  UTILITY: "utility",
};

// Configurações de grupos de comandos
export const COMMAND_GROUPS_CONFIG = {
  [COMMAND_CATEGORIES.BACKUP]: {
    name: "backup",
    description: "Comandos de backup",
  },
  [COMMAND_CATEGORIES.RESTORE]: {
    name: "restore",
    description: "Comandos de restauração",
  },
  [COMMAND_CATEGORIES.SETUP]: {
    name: "setup",
    description: "Comandos de configuração",
  },
};

// Categorias que devem ser registradas como grupos de comandos
export const GROUPED_CATEGORIES = [
  COMMAND_CATEGORIES.BACKUP,
  COMMAND_CATEGORIES.RESTORE,
  COMMAND_CATEGORIES.SETUP,
];

// Categorias que são comandos standalone
export const STANDALONE_CATEGORIES = [COMMAND_CATEGORIES.UTILITY];

/**
 * Verifica se uma categoria deve ser registrada como grupo
 * @param {string} category - Nome da categoria
 * @returns {boolean}
 */
export function isGroupedCategory(category) {
  return GROUPED_CATEGORIES.includes(category);
}

/**
 * Obtém a configuração de um grupo de comandos
 * @param {string} category - Nome da categoria
 * @returns {Object|null} Configuração do grupo ou null se não existir
 */
export function getGroupConfig(category) {
  return COMMAND_GROUPS_CONFIG[category] || null;
}

/**
 * Verifica se um comando é o comando principal de um grupo
 * (ex: setup.js é o principal do grupo setup)
 * @param {string} commandName - Nome do comando
 * @param {string} category - Categoria do comando
 * @returns {boolean}
 */
export function isGroupMainCommand(commandName, category) {
  const groupConfig = getGroupConfig(category);
  return groupConfig && commandName === groupConfig.name;
}
