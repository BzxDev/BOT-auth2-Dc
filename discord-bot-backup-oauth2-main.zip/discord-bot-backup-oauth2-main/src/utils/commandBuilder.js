import {
  isGroupedCategory,
  getGroupConfig,
  isGroupMainCommand,
  COMMAND_GROUPS_CONFIG,
} from "./commandCategories.js";

const SUB_COMMAND_TYPE = 1;
const CHAT_INPUT_TYPE = 1;

/**
 * Classe para construir estrutura de comandos do Discord
 */
export class CommandBuilder {
  constructor(commands) {
    this.commands = commands;
    this.commandGroups = new Map();
    this.standaloneCommands = [];
  }

  /**
   * Processa todos os comandos e organiza em grupos e standalone
   */
  processCommands() {
    // Inicializar grupos
    for (const category of Object.keys(COMMAND_GROUPS_CONFIG)) {
      const config = getGroupConfig(category);
      if (config) {
        this.commandGroups.set(category, {
          ...config,
          options: [],
          hasSubcommands: false,
        });
      }
    }

    // Coletar informações sobre comandos de setup para decisão especial
    const setupInfo = this._analyzeSetupCommands();

    // Processar cada comando
    for (const [name, command] of this.commands) {
      const category = command.category;

      if (isGroupedCategory(category)) {
        this._processGroupedCommand(name, command, category, setupInfo);
      } else {
        this._processStandaloneCommand(name, command);
      }
    }
  }

  /**
   * Analisa comandos de setup para decidir se setup.js será standalone ou subcomando
   * @returns {Object} Informações sobre comandos de setup
   */
  _analyzeSetupCommands() {
    const setupSubcommands = [];
    let setupMainCommand = null;

    for (const [name, command] of this.commands) {
      if (command.category === "setup") {
        if (isGroupMainCommand(name, "setup")) {
          setupMainCommand = { name, command };
        } else {
          setupSubcommands.push({ name, command });
        }
      }
    }

    return {
      subcommands: setupSubcommands,
      mainCommand: setupMainCommand,
      hasSubcommands: setupSubcommands.length > 0,
    };
  }

  /**
   * Processa um comando que pertence a um grupo
   * @param {string} name - Nome do comando
   * @param {Object} command - Objeto do comando
   * @param {string} category - Categoria do comando
   * @param {Object} setupInfo - Informações sobre comandos de setup
   */
  _processGroupedCommand(name, command, category, setupInfo) {
    const group = this.commandGroups.get(category);

    if (!group) {
      // Se o grupo não existe, tratar como standalone
      this._addStandaloneCommand(name, command);
      return;
    }

    // Caso especial para setup.js
    if (category === "setup" && isGroupMainCommand(name, category)) {
      // setup.js só é registrado como standalone se NÃO houver subcomandos
      if (!setupInfo.hasSubcommands) {
        this._addStandaloneCommand(name, command);
      }
      // Se houver subcomandos, setup.js é ignorado (evita duplicação)
      return;
    }

    // Adicionar como subcomando do grupo
    group.options.push({
      name,
      description: command.description,
      type: SUB_COMMAND_TYPE,
      options: command.options || [],
    });
    group.hasSubcommands = true;
  }

  /**
   * Processa um comando standalone
   * @param {string} name - Nome do comando
   * @param {Object} command - Objeto do comando
   */
  _processStandaloneCommand(name, command) {
    this._addStandaloneCommand(name, command);
  }

  /**
   * Adiciona um comando standalone à lista
   * @param {string} name - Nome do comando
   * @param {Object} command - Objeto do comando
   */
  _addStandaloneCommand(name, command) {
    this.standaloneCommands.push({
      name,
      description: command.description,
      type: CHAT_INPUT_TYPE,
      options: command.options || [],
    });
  }

  /**
   * Constrói a estrutura final de comandos para o Discord API
   * @returns {Array} Array de comandos formatados para Discord API
   */
  build() {
    const commands = [...this.standaloneCommands];

    // Adicionar grupos que têm subcomandos
    for (const group of this.commandGroups.values()) {
      if (group.hasSubcommands && group.options.length > 0) {
        commands.push({
          name: group.name,
          description: group.description,
          type: CHAT_INPUT_TYPE,
          options: group.options,
        });
      }
    }

    return commands;
  }
}

/**
 * Constrói estrutura de comandos a partir de uma Collection de comandos
 * @param {Collection} commands - Collection de comandos do Discord.js
 * @returns {Array} Array de comandos formatados para Discord API
 */
export function buildCommandStructure(commands) {
  const builder = new CommandBuilder(commands);
  builder.processCommands();
  return builder.build();
}

