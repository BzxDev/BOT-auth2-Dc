import express from "express";
import config from "../config/config.js";
import logger from "../utils/logger.js";
import oauth2Routes from "../web/routes/oauth2.js";

class WebServer {
  constructor(client) {
    this.client = client;
    this.app = express();
    this.setupRoutes();
  }

  setupRoutes() {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));

    // Health check endpoint
    this.app.get("/health", (req, res) => {
      res.json({ status: "ok" });
    });

    // OAuth2 routes
    this.app.use("/oauth2", oauth2Routes(this.client));

    // Error handler
    this.app.use((err, req, res, next) => {
      logger.error("Web server error:", err);
      res.status(500).json({ error: "Internal server error" });
    });
  }

  start() {
    return new Promise((resolve, reject) => {
      try {
        this.server = this.app.listen(config.server.port, () => {
          logger.info(`Web server started on port ${config.server.port}`);
          resolve();
        });
      } catch (error) {
        logger.error("Failed to start web server:", error);
        reject(error);
      }
    });
  }

  stop() {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          logger.info("Web server stopped");
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
}

export default WebServer;
