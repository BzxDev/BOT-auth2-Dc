import {
  Client,
  Collection,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
} from "discord.js";
import { readdirSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import config from "../config/config.js";
import logger from "../utils/logger.js";
import { buildCommandStructure } from "../utils/commandBuilder.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class BotClient extends Client {
  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences,
      ],
      partials: [Partials.User, Partials.Message, Partials.Channel],
    });

    this.commands = new Collection();
    this.backupQueue = new Map();
  }

  /**
   * Carrega um comando de um arquivo
   * @param {string} filePath - Caminho do arquivo do comando
   * @param {string} category - Categoria do comando (opcional)
   * @param {string} fileName - Nome do arquivo (para logs)
   * @returns {Promise<Object|null>} Comando carregado ou null se falhar
   */
  async _loadCommandFromFile(filePath, category = null, fileName = null) {
    try {
      const commandModule = await import(`file://${filePath}`);
      const command = commandModule.default;

      if (!command.name || !command.execute) {
        logger.warn(
          `Command ${fileName || filePath} missing name or execute method`
        );
        return null;
      }

      const categoryInfo = category ? `${category}/` : "";
      logger.info(
        `Loaded command: ${categoryInfo}${command.name} (category: ${command.category || "none"})`
      );

      if (command.options) {
        logger.info(`  Options: ${command.options.length} option(s)`);
      }

      return command;
    } catch (error) {
      logger.error(`Error loading command ${fileName || filePath}:`, error);
      return null;
    }
  }

  /**
   * Carrega comandos de um diretório
   * @param {string} directoryPath - Caminho do diretório
   * @param {string} category - Categoria dos comandos
   */
  async _loadCommandsFromDirectory(directoryPath, category) {
    const commandFiles = readdirSync(directoryPath).filter((file) =>
      file.endsWith(".js")
    );

    for (const file of commandFiles) {
      const filePath = join(directoryPath, file);
      const command = await this._loadCommandFromFile(filePath, category, file);

      if (command) {
        this.commands.set(command.name, command);
      }
    }
  }

  /**
   * Carrega todos os comandos do diretório de comandos
   */
  async loadCommands() {
    const commandsPath = join(__dirname, "../commands");
    const entries = readdirSync(commandsPath, { withFileTypes: true });

    for (const entry of entries) {
      if (entry.isDirectory()) {
        // Carregar comandos de subdiretórios (categorias)
        const categoryPath = join(commandsPath, entry.name);
        await this._loadCommandsFromDirectory(categoryPath, entry.name);
      } else if (entry.isFile() && entry.name.endsWith(".js")) {
        // Carregar comandos standalone do diretório raiz
        const commandPath = join(commandsPath, entry.name);
        const command = await this._loadCommandFromFile(
          commandPath,
          null,
          entry.name
        );

        if (command) {
          this.commands.set(command.name, command);
        }
      }
    }
  }

  /**
   * Registra comandos slash no Discord
   */
  async registerSlashCommands() {
    try {
      // Construir estrutura de comandos usando o builder
      const commands = buildCommandStructure(this.commands);

      const rest = new REST({ version: "10" }).setToken(config.bot.token);
      logger.info("Registering slash commands...");

      await rest.put(Routes.applicationCommands(config.bot.clientId), {
        body: commands,
      });

      logger.info(`Successfully registered ${commands.length} slash commands`);
    } catch (error) {
      logger.error("Error registering commands:", error);
      throw error;
    }
  }
}

export default BotClient;
