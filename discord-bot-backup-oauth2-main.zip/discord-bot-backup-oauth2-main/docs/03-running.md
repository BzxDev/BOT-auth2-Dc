# Como Usar

## Comandos Disponíveis

### Backup

#### Criar Backup
```
/backup criar [nome]
```
Cria um novo backup do servidor. Você pode escolher quais componentes incluir:
- Configurações do Servidor
- Canais
- Cargos
- Membros
- Emojis
- Stickers
- Permissões

#### Listar Backups
```
/backup listar
```
Lista todos os backups do servidor com informações básicas.

#### Informações do Backup
```
/backup info <backup_id>
```
Mostra informações detalhadas de um backup específico.

#### Deletar Backup
```
/backup deletar <backup_id>
```
Deleta um backup. Requer confirmação.

#### Backup Automático
```
/backup autobackup
```
Configura backups automáticos com intervalos pré-definidos:
- 1 Semana
- 2 Semanas
- 3 Semanas
- 1 Mês

### Restauração

#### Iniciar Restauração
```
/restore iniciar <backup_id> [servidor_alvo]
```
Inicia a restauração de um backup. Se `servidor_alvo` não for especificado, restaura no servidor atual.

#### Status da Restauração
```
/restore status <restore_id>
```
Verifica o progresso de uma restauração em andamento.

### Configuração

#### Setup (Modo de Restauração)
```
/setup tipo:automatic
/setup tipo:manual
```
Configura o modo de restauração do bot:
- **Automatic:** Bot cria todos os canais durante restauração
- **Manual:** Bot apenas configura canais existentes + permite coletar OAuth2

**Nota:** Este comando deve ser executado pelo menos uma vez após instalar o bot.

### Utilidades

#### Ping
```
/ping
```
Verifica a latência do bot e da API do Discord.

#### Help
```
/help
```
Mostra a lista de todos os comandos disponíveis.

## Fluxo de Backup

1. Execute `/backup criar [nome]`
2. Selecione os componentes desejados no menu
3. Aguarde a confirmação
4. O backup será armazenado no MongoDB

## Fluxo de OAuth2

1. Execute `/setup tipo:manual` em qualquer canal
2. Selecione o canal onde a embed será enviada
3. Um embed será enviado no canal escolhido com um botão "Autorizar"
4. Usuários clicam no botão "Autorizar"
5. São redirecionados para autorização do Discord
6. Após autorizar, são redirecionados de volta
7. Tokens são armazenados com criptografia AES-256

**Para que serve:** Os tokens OAuth2 permitem que o bot re-adicione membros ao servidor após um mass ban ou raid.

## Fluxo de Restauração

1. Execute `/restore iniciar <backup_id>`
2. O bot começará a restaurar componentes
3. Use `/restore status <restore_id>` para acompanhar o progresso
4. Membros serão restaurados usando tokens OAuth2 armazenados

## Backups Automáticos

1. Execute `/backup autobackup`
2. Selecione o intervalo desejado
3. Selecione os componentes
4. Backups serão criados automaticamente no intervalo configurado

## Permissões e Requisitos

### Permissões de Usuário

Para executar comandos de backup, restauração e configuração, o usuário precisa:

**Opção 1:** Ter permissão **Administrator** no servidor

**OU**

**Opção 2:** Estar na lista de `ADMIN_IDS` (configurada no arquivo `.env`)

**Comandos que requerem permissões:**
- Todos os comandos `/backup`
- Todos os comandos `/restore`
- Comando `/setup`

**Comandos disponíveis para todos:**
- `/ping`
- `/help`

### Permissões do Bot

O bot precisa de permissões extensivas para funcionar corretamente.

#### ✅ Recomendado: Administrator

A forma mais simples e segura é convidar o bot com permissão **Administrator**:

**Vantagens:**
- Garante que todas as funcionalidades funcionem
- Não precisa se preocupar com permissões individuais
- Simplifica troubleshooting

**Como verificar:**
1. Vá em **Configurações do Servidor** → **Cargos**
2. Localize o cargo do bot
3. Verifique se "Administrator" está marcado

#### 📋 Alternativa: Permissões Específicas

Se preferir não dar Administrator, o bot precisa de TODAS estas permissões:

| Permissão | Para que serve |
|-----------|----------------|
| **Manage Guild** | Restaurar configurações do servidor (nome, descrição, etc.) |
| **Manage Channels** | Criar, editar e deletar canais durante restauração |
| **Manage Roles** | Criar, editar e atribuir cargos durante restauração |
| **Manage Nicknames** | Restaurar apelidos dos membros |
| **Manage Emojis and Stickers** | Restaurar emojis e stickers personalizados |
| **View Channel** | Ler informações de canais para backup |
| **Read Message History** | Ler histórico e informações dos canais |
| **Send Messages** | Enviar confirmações e embeds |
| **Embed Links** | Enviar embeds formatados |

**Como configurar:**
1. Vá em **Configurações do Servidor** → **Cargos**
2. Localize o cargo do bot
3. Marque todas as permissões listadas acima

### ⚠️ CRÍTICO: Posição do Cargo

**Mesmo com todas as permissões, o cargo do bot DEVE estar no topo da hierarquia!**

**Por quê?** O Discord usa hierarquia de cargos. Um bot só pode:
- Gerenciar cargos que estão **abaixo** do seu próprio cargo
- Editar canais criados por cargos **abaixo** do seu próprio cargo

**Como verificar:**
1. Vá em **Configurações do Servidor** → **Cargos**
2. O cargo do bot deve estar no **topo da lista** (acima de todos os outros)
3. Se não estiver, arraste-o para cima

**Sintomas de cargo mal posicionado:**
- Erros "Missing Permissions" durante restauração
- Mensagem "Role position is higher than bot's role"
- Cargos ou canais não sendo criados/editados

### Como Verificar se o Bot Está Configurado Corretamente

Execute este checklist:

1. **Bot está online?** ✓ Deve aparecer online no servidor
2. **Cargo no topo?** ✓ Vá em Cargos e verifique que está acima de todos
3. **Tem permissões?** ✓ Administrator OU todas as permissões listadas acima
4. **Setup executado?** ✓ Execute `/setup tipo:automatic` ou `/setup tipo:manual`
5. **Comandos funcionam?** ✓ Teste com `/ping` e `/backup criar teste`

### Troubleshooting de Permissões

**Problema:** "❌ Permissões Insuficientes do Bot"

**Solução:**
1. Verifique se o bot tem permissão Administrator
2. OU verifique se tem TODAS as permissões da lista acima
3. Verifique se o cargo do bot está no topo da hierarquia

**Problema:** "❌ Você não tem permissões para usar este comando"

**Solução:**
1. Verifique se você tem permissão Administrator no servidor
2. OU adicione seu ID de usuário em `ADMIN_IDS` no arquivo `.env`
3. Reinicie o bot após alterar `.env`

**Problema:** Restauração falha com "Missing Access" ou "Missing Permissions"

**Solução:**
1. **VERIFIQUE O CARGO DO BOT ESTÁ NO TOPO** (problema mais comum!)
2. Verifique se o bot tem permissão "Manage Roles"
3. Verifique se o bot tem permissão "Manage Channels"
4. Verifique logs do bot para detalhes do erro

**Problema:** Bot não consegue restaurar alguns cargos específicos

**Solução:**
- O cargo do bot DEVE estar acima do cargo que você quer restaurar
- Arraste o cargo do bot para o topo da lista
- Tente a restauração novamente
