# Configuração

## ✅ Checklist Pré-Instalação

Antes de começar, certifique-se de ter:

- [ ] Bot criado no Discord Developer Portal
- [ ] Token do bot copiado
- [ ] OAuth2 configurado com redirect URI correto
- [ ] Bot convidado ao servidor com permissão Administrator (ou todas as permissões necessárias)
- [ ] **Cargo do bot movido para a posição mais alta na hierarquia de cargos**
- [ ] MongoDB instalado e acessível (local ou Atlas)
- [ ] Node.js 20+ instalado
- [ ] Variáveis de ambiente configuradas no arquivo `.env`

## Configuração do Bot no Discord

### 1. Criar Aplicação

1. Acesse [Discord Developer Portal](https://discord.com/developers/applications)
2. Clique em "New Application"
3. Dê um nome à aplicação
4. Clique em "Create"

### 2. Configurar Bot

1. Vá para a aba "Bot"
2. Clique em "Add Bot"
3. Copie o **Token** (você precisará dele)
4. Ative as **Privileged Gateway Intents**:
   - Server Members Intent
   - Message Content Intent

### 3. Configurar OAuth2

1. Vá para "OAuth2" → "URL Generator"
2. Selecione os scopes:
   - `bot`
   - `guilds.join`
   - `identify`
3. Selecione as permissões do bot (veja seção "Permissões Necessárias" abaixo):
   - **Administrator** (recomendado - inclui todas as permissões)
   - OU todas as permissões específicas listadas abaixo
4. Configure o Redirect URI:
   - `https//seu-dominio.com/oauth2/callback` (desenvolvimento)
   - `https://seu-dominio.com/oauth2/callback` (produção)
5. Salve as alterações

### 4. Convidar Bot

1. Copie a URL gerada
2. Cole no navegador
3. Selecione o servidor
4. Autorize o bot

### 5. ⚠️ CRÍTICO: Configurar Posição do Cargo do Bot

**ESTE PASSO É OBRIGATÓRIO** - O bot NÃO funcionará corretamente sem isso!

Após convidar o bot ao servidor, você DEVE mover o cargo dele para a posição mais alta:

1. Abra **Configurações do Servidor**
2. Vá para **Cargos**
3. Localize o cargo do bot (geralmente tem o mesmo nome do bot)
4. **Arraste o cargo do bot para o TOPO da lista** (acima de todos os outros cargos)
5. Salve as alterações

**Por que isso é necessário?**

O Discord usa hierarquia de cargos para determinar permissões. Um bot só pode gerenciar cargos e canais que estão **abaixo** do seu próprio cargo na hierarquia. Durante a restauração, o bot precisa:

- Criar e editar cargos (incluindo cargos administrativos)
- Criar e configurar canais
- Atribuir cargos aos membros

Se o cargo do bot não estiver no topo, a restauração de cargos/canais falhará com erros de permissão, mesmo que o bot tenha a permissão "Administrator".

**Verificação:** Após mover o cargo, ele deve aparecer no topo da lista, acima de todos os outros cargos do servidor.

## Permissões Necessárias

### Opção 1: Administrator (Recomendado)

A forma mais simples é convidar o bot com a permissão **Administrator**. Isso garante que o bot tenha todas as permissões necessárias automaticamente.

✅ **Vantagens:**
- Configuração simples e rápida
- Garante que todas as funcionalidades funcionem
- Não precisa se preocupar com permissões individuais

⚠️ **Nota:** Mesmo com Administrator, o cargo do bot AINDA precisa estar no topo da hierarquia!

### Opção 2: Permissões Específicas

Se preferir não dar Administrator, o bot precisa das seguintes permissões:

#### Permissões do Servidor
- **Manage Guild** (`ManageGuild`) - Para restaurar configurações do servidor (nome, descrição, etc.)

#### Permissões de Canais
- **Manage Channels** (`ManageChannels`) - Para criar, editar e deletar canais
- **View Channel** (`ViewChannel`) - Para ler informações de canais
- **Read Message History** (`ReadMessageHistory`) - Para ler informações dos canais

#### Permissões de Cargos e Membros
- **Manage Roles** (`ManageRoles`) - Para criar, editar e atribuir cargos
- **Manage Nicknames** (`ManageNicknames`) - Para restaurar apelidos de membros

#### Permissões de Conteúdo
- **Manage Emojis and Stickers** (`ManageEmojisAndStickers`) - Para restaurar emojis e stickers personalizados

#### Permissões de Mensagens
- **Send Messages** (`SendMessages`) - Para enviar mensagens e embeds
- **Embed Links** (`EmbedLinks`) - Para enviar embeds formatados

**Lista para copiar (OAuth2 URL Generator):**
```
Administrator (recomendado)

OU

Manage Guild
Manage Channels
Manage Roles
Manage Nicknames
Manage Emojis and Stickers
View Channel
Read Message History
Send Messages
Embed Links
```

## Variáveis de Ambiente

Crie um arquivo `.env` baseado no `env.example`:

```env
# Bot Configuration
BOT_TOKEN=seu-token-aqui
CLIENT_ID=seu-client-id
CLIENT_SECRET=seu-client-secret
REDIRECT_URI=https//seu-dominio.com/oauth2/callback

# Database
DATABASE=mongodb://user:pass@localhost:27017/backup-bot

# Web Server
PORT=80

# Optional
ENCRYPTION_KEY=sua-chave-personalizada
ADMIN_IDS=123456789,987654321
LOG_LEVEL=info
```

### Encryption Key (Opcional)

A `ENCRYPTION_KEY` é opcional. Se não fornecida, o bot usará o `CLIENT_SECRET` como base para criptografia. Você pode fornecer qualquer string de qualquer tamanho - ela será derivada usando SHA-256.

## Comando de Configuração Inicial

Após o bot estar online no servidor, você DEVE executar o comando de setup para configurar o modo de restauração.

### Executar Setup

Execute um dos seguintes comandos no Discord:

#### Modo Automático (Recomendado para recuperação completa)
```
/setup tipo:automatic
```

**O que faz:** Durante a restauração, o bot irá **criar automaticamente** todos os canais, cargos e estruturas do backup.

**Quando usar:**
- Recuperação após raid/ataque
- Restauração completa do servidor
- Migração de servidor

#### Modo Manual (Para coleta de OAuth2)
```
/setup tipo:manual
```

**O que faz:** Durante a restauração, o bot irá **apenas configurar canais existentes** (não cria novos). Além disso, solicita um canal para enviar a embed de autorização OAuth2.

**Quando usar:**
- Quando você quer coletar tokens OAuth2 dos membros
- Restauração parcial (apenas configurações, não estrutura)
- Quando não quer que o bot crie canais novos

### Fluxo do Modo Manual (OAuth2)

Se você escolher o modo Manual, o bot pedirá que você selecione um canal:

1. Execute `/setup tipo:manual`
2. Selecione um canal da lista (ex: #geral, #avisos)
3. O bot enviará uma embed nesse canal com um botão "Autorizar"
4. Peça aos membros do servidor que cliquem no botão
5. Cada membro será redirecionado para autorizar o bot
6. Os tokens OAuth2 serão armazenados com criptografia AES-256

**Por que coletar tokens OAuth2?**

Os tokens OAuth2 permitem que o bot **re-adicione membros ao servidor** após um mass ban ou raid. Sem os tokens, o bot pode restaurar a estrutura do servidor (canais, cargos), mas não pode trazer os membros de volta.

### Exemplo da Embed OAuth2

Quando você executa o modo Manual, os membros verão:

```
╔══════════════════════════════════╗
║   Autorização OAuth2             ║
╠══════════════════════════════════╣
║ Para restaurar membros após      ║
║ um incidente de segurança        ║
║ (raid ou mass ban), você         ║
║ precisa autorizar o bot.         ║
║                                  ║
║ Como funciona:                   ║
║ 1. Clique no botão abaixo        ║
║ 2. Autorize o bot no Discord     ║
║ 3. Seu token será armazenado     ║
║    com segurança (criptografado) ║
║                                  ║
║                                  ║
╚══════════════════════════════════╝
[🔐 Autorizar]
```

### Alternar entre Modos

Você pode executar o comando `/setup` novamente a qualquer momento para alterar o modo de restauração. A configuração mais recente será usada nas próximas restaurações.

## Configuração do MongoDB

### MongoDB Local

```bash
# Instalar MongoDB
# Ubuntu/Debian
sudo apt-get install mongodb

# macOS
brew install mongodb-community

# Iniciar MongoDB
sudo systemctl start mongodb  # Linux
brew services start mongodb-community  # macOS
```

### MongoDB Atlas (Cloud)

1. Acesse [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Crie uma conta gratuita
3. Crie um cluster
4. Configure acesso de rede (0.0.0.0/0 para desenvolvimento)
5. Crie um usuário de banco
6. Copie a connection string e use no `DATABASE`

## Verificação

Após configurar tudo, execute:

```bash
npm run dev
```

O bot deve conectar e aparecer online no Discord.
