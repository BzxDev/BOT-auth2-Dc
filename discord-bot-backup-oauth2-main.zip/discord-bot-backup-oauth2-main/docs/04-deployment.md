## Deploy em Produção

### Requisitos

- Servidor com Node.js 20+
- MongoDB (local ou Atlas)
- Domínio com SSL (para OAuth2 callback)

### Passos

1. **Configure o Redirect URI**
   - No Discord Developer Portal, configure o Redirect URI para seu domínio
   - Exemplo: `https://seu-dominio.com/oauth2/callback`

2. **Configure Variáveis de Ambiente**
   ```env
   REDIRECT_URI=https://seu-dominio.com/oauth2/callback
   DATABASE=mongodb+srv://user:pass@cluster.mongodb.net/backup-bot
   PORT=80
   ```

3. **Use PM2 para Gerenciar Processo**
   ```bash
   npm install -g pm2
   pm2 start src/index.js --name backup-bot
   pm2 save
   pm2 startup
   ```

4. **Configure Nginx (Opcional)**
   ```nginx
   server {
       listen 80;
       server_name seu-dominio.com;

       location / {
           proxy_pass https//seu-dominio.com;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

5. **Configure SSL com Let's Encrypt**
   ```bash
   sudo apt install certbot python3-certbot-nginx
   sudo certbot --nginx -d seu-dominio.com
   ```

## Segurança

### Boas Práticas

1. **Nunca commite o arquivo `.env`**
2. **Use chaves de criptografia fortes** (32 caracteres aleatórios)
3. **Limite acesso ao MongoDB** (firewall, IP whitelist)
4. **Use HTTPS em produção** (obrigatório para OAuth2)
5. **Monitore logs** regularmente
6. **Mantenha dependências atualizadas**

### Firewall

```bash
# Permitir apenas portas necessárias
sudo ufw allow 22/tcp   # SSH
sudo ufw allow 80/tcp   # HTTP
sudo ufw allow 443/tcp  # HTTPS
sudo ufw enable
```

## Monitoramento

### Logs

Os logs são estruturados e incluem:
- Timestamp
- Nível (error, warn, info, debug)
- Mensagem
- Contexto adicional

### Health Check

O endpoint `/health` retorna o status do servidor:

```bash
curl https//seu-dominio.com/health
# {"status":"ok"}
```

### Backup do Banco de Dados

Configure backups regulares do MongoDB:

```bash
# Backup manual
mongodump --uri="mongodb://user:pass@localhost:27017/backup-bot" --out=/backup/$(date +%Y%m%d)

# Restore
mongorestore --uri="mongodb://user:pass@localhost:27017/backup-bot" /backup/20240101
```

## Troubleshooting

### Bot não conecta

- Verifique se o `BOT_TOKEN` está correto
- Verifique se as intents estão habilitadas no Discord Developer Portal

### OAuth2 não funciona

- Verifique se o `REDIRECT_URI` está configurado corretamente no Discord
- Verifique se está usando HTTPS em produção
- Verifique os logs do servidor web

### Erro de conexão com MongoDB

- Verifique a connection string
- Verifique se o MongoDB está rodando
- Verifique firewall/network access
