# Introdução

## O que é este bot?

O Bot Discord Backup OAuth2 é uma solução completa para fazer backup de servidores Discord e restaurar membros após incidentes de segurança como raids ou mass bans.

## ⚠️ Antes de Começar

Antes de instalar e configurar o bot, você precisa estar ciente de alguns requisitos críticos:

### 🔴 Cargo do Bot na Posição Mais Alta

**REQUISITO OBRIGATÓRIO:** O cargo do bot DEVE estar na posição mais alta da hierarquia de cargos do servidor.

Após convidar o bot:
1. Vá em **Configurações do Servidor** → **Cargos**
2. Arraste o cargo do bot para o **topo** (acima de todos os outros)
3. Salve

**Por quê?** O Discord usa hierarquia de cargos. Um bot só pode gerenciar cargos/canais que estão abaixo do seu próprio cargo. Para restaurar cargos administrativos e canais importantes, o bot precisa estar no topo.

### 🔐 Permissões Necessárias

O bot precisa de permissões extensivas para funcionar:

**Recomendado:** Convide com permissão **Administrator** (mais simples)

**Alternativa:** Se não quiser dar Administrator, veja a lista completa de permissões em `02-configuration.md`

### ⚙️ Comando de Setup

Após o bot estar online, você DEVE executar o comando de configuração inicial:

```
/setup tipo:automatic  (ou)  /setup tipo:manual
```

Este comando configura como o bot fará restaurações e, no modo manual, permite coletar tokens OAuth2 dos membros.

### 📋 Documentação Detalhada

Para instruções passo a passo completas, consulte:
- `02-configuration.md` - Configuração detalhada com todos os passos
- `03-running.md` - Como usar o bot após configurado
- `04-deployment.md` - Deploy em produção

## Características Principais

### Backup Seletivo
- Escolha quais componentes incluir no backup
- Suporte para: configurações do servidor, canais, cargos, membros, emojis, stickers e permissões
- Compressão automática para economizar espaço

### Backups Automáticos
- Configure backups automáticos com intervalos pré-definidos
- Opções: 1 semana, 2 semanas, 3 semanas, 1 mês
- Nomeação automática com data

### OAuth2 Integration
- Coleta tokens OAuth2 dos usuários
- Permite restaurar membros em servidores após incidentes
- Tokens armazenados com criptografia AES-256

### Restauração Completa
- Restaure servidores completos ou componentes específicos
- Restauração de membros usando tokens OAuth2
- Progresso em tempo real

## Casos de Uso

1. **Proteção contra Raids**: Faça backup antes de um evento conhecido
2. **Recuperação após Mass Ban**: Restaure membros após um mass ban acidental
3. **Migração de Servidor**: Migre servidores completos para novos servidores
4. **Backup Regular**: Configure backups automáticos para manter histórico

## Requisitos

- Node.js 20+
- MongoDB 4.4+
- Bot Discord com permissões adequadas
